# COMP4770
CS 4770 team project

## Here's a list of what couldn't be implemented in time:
[System Documentation Corrections](https://github.com/bdfagan/COMP4770/wiki/System-Documentation-Corrections)

# To build:
1. Pull or clone repo
2. Navigate to root directory in shell
3. Type `npm install` or `npm i`

# To run:
1. Navigate to root directory
2. Type `node index.js`
3. In your browser, go to `localhost:8000`

## Docker
Make sure you have Docker installed.
We have defined our Dockerfile inside the COMP4770 directory, navigate to this directory to execute the following commands.

# To Build:
1. `docker build -t game-docker .`

# To Run:
1. `docker run -p 8000:8000 -d game-docker`
2. In your browser, go to `localhost:8000`
