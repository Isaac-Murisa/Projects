const express = require("express");
const router = express.Router();

// Connect to database
const db = require("../database/db");

// Handle encrypting passwords
const crypto = require("crypto");
const authTokens = {};
function generateAuthToken() {
    return crypto.randomBytes(30).toString('hex');
}
function hashPassword(password) {
    const sha256 = crypto.createHash('sha256');
    const hash = sha256.update(password).digest('base64');
    return hash;
};

// Expose the Account and Level models for ease of use
const Account = db.schema.Account;
const Level = db.schema.Level;
const Score = db.schema.Score;

// === 'GET' ROUTES ===

// GET /db/levels will return a JSON containing all the levels
// - to be used for the User Level selection screen
router.get("/db/levels", function (req, res) {
    Level.find({}, function (err, levels) {
        if (err) return res.json(err);
        return res.json({ levels: levels });
    });
});

// GET /db/levels/:level_ID will return a level object matching
// the level_ID parameter. Used to fetch a single level.
// Params: level_ID
// Return: JSON for the level with that ID
router.get("/db/levels/:level_ID", function (req, res) {
    Level.findOne({ level_ID: req.params.level_ID }, function (err, levels) {
        if (err) return res.json(err);
        return res.json(levels);
    });
});

// GET /db/accounts exposes all registered accounts and should
// ABSOLUTELY NOT be used in production
router.get("/db/accounts", function (req, res) {
    Account.find({}, function (err, accounts) {
        if (err) return res.json(err);
        return res.json({ accounts });
    });
});

// GET /db/scores will show all registered scores in the Scores collection
router.get("/db/scores", function (req, res) {
    Score.find({}, function (err, scores) {
        if (err) return res.json(err);
        return res.json({ scores });
    });
});
// GET /db/scores/user/:username will show all registered scores submitted
//      by a single user
// Params: username (String)
router.get("/db/scores/user/:username", function (req, res) {
    Score.find({ username: req.params.username }, function (err, scores) {
        if (err) return res.json(err);
        return res.json({ scores });
    });
});
// GET /db/scores/level/:level_ID will show all registered scores submitted
//      for a single level
// Params: level_ID (String)
router.get("/db/scores/level/:level_ID", function (req, res) {
    Score.find({ level_ID: req.params.level_ID }).sort({ "score": -1 }).limit(10).exec(function (err, scores) {
        if (err) return res.json(err);
        return res.json({ scores });
    });
});
// GET /db/scores/:score_ID will show a single score by its unique ID in Mongo
//      May not be necessary.
// Params: score_ID (String), matching the Mongo document's "_id" value.
router.get("/db/scores/:score_ID", function (req, res) {
    Score.findOne({ _id: req.params.score_ID }, function (err, score) {
        if (err) return res.json(err);
        return res.json(score);
    });
});

/**
* Check if cookie already exsists, if it does, automatically sign in user
*/
router.get("/checkCookie", function (req, res) {
    if (req.cookies.NinjaCelesteAuthToken in authTokens) {
        console.log("Logged-in cookie detected!");
        return res.json({ success: true, token: authTokens[req.cookies.NinjaCelesteAuthToken], message: "Welcome back, " + authTokens[req.cookies.NinjaCelesteAuthToken].username + "!" });
    }
    else {
        return res.json({ success: false });
    }
});

router.get("/db/user/:username", function (req, res) {
    Account.findOne({ username: username }, function (err, user) {
        if (err) return res.json(err);
        return res.json({
            username: username,
            campaign_scores: campaign_scores,
            campaign_pickups: campaign_pickups
        });
    });
});


// === 'POST' ROUTES ===

// POST /db/accounts is our login function
/* Params: {
    username, password
    }
    Returns JSON for that account in the Accounts table.
*/
router.post("/login", function (req, res) {
    const username = req.body.username;
    const password = req.body.password;
    const hashedPassword = hashPassword(password);
    Account.findOne(
        { username: req.body.username },
        function (err, user) {
            if (err) return res.json(err);
            if (!user) {
                return res.json({ success: false, message: "User not found" });
            }
            if (hashedPassword !== user.password) {
                return res.json({ success: false, message: "Incorrect password" });
            }
            const token = generateAuthToken();

            authTokens[token] = user;

            res.cookie('NinjaCelesteAuthToken', token);

            res.json({ success: true, token: token, username: user.username, campaign_pickups: user.campaign_pickups, campaign_scores: user.campaign_scores });
            return;
        });

});

router.post("/logout", function (req, res) {
    if (!req.cookies.NinjaCelesteAuthToken) return res.json({ success: false, message: "You are not logged in." });
    if (req.cookies.NinjaCelesteAuthToken in authTokens) {
        let username = authTokens[req.cookies.NinjaCelesteAuthToken].username;
        delete authTokens[req.cookies.NinjaCelesteAuthToken];
        res.clearCookie('NinjaCelesteAuthToken');
        res.json({ success: true, message: "See you soon, " + username + "!" });
    } else {
        res.json({ success: false, message: "Token invalid. Try logging in again first." });
    }
});

// POST /db/addUSer will register a new user in the database
/* Params: { 
     String username (must be unique), 
     String password (new password), 
     String confirmPassword (same as password),
     String email (email address) 
    }
*/
router.post("/db/addUser", function (req, res) {
    if (req.body.password !== req.body.confirmPassword) return res.json({ success: false, message: "Passwords must match." });
    const hashedPassword = hashPassword(req.body.password);

    let newUser = new Account({
        username: req.body.username,
        password: hashedPassword,
        email: req.body.email,
        campaign_scores: {}
    });
    newUser.save(function (err) {
        if (err) {
            if (err.errmsg.includes(req.body.username))
                return res.json({
                    message: "Username already taken.",
                    success: false,
                    ...err
                });
            if (err.errmsg.includes(req.body.email))
                return res.json({
                    message: "Email already in use.",
                    success: false,
                    ...err
                });
            return res.json({ err });
        }
        return res.json({ success: true, username: req.body.username, campaign_pickups: {}, campaign_scores: {} });
    });
});

// POST /db/addLevel will register a new level in the database
/* Params: { 
    String levelid, 
    String author (username of author), 
    String data (the string that encodes the level) 
    }
*/
router.post("/db/addLevel", function (req, res) {
    const levelid = req.body.levelid;
    const author = authTokens[req.cookies.NinjaCelesteAuthToken].username;
    const data = req.body.data;

    let newLevel = new Level({
        level_ID: levelid,
        author: author,
        data: data,
        highscore_object: {}
    });
    newLevel.save(function (err, level) {
        if (err) return console.error(err);
        console.log("Level " + newLevel.level_ID + " saved.");
        return res.json({ success: true });
    });
});

router.post("/db/addScore", function (req, res) {
    const levelid = req.body.levelid;
    const username = authTokens[req.cookies.NinjaCelesteAuthToken].username;
    const score = req.body.score;
    const date = new Date();

    let newScore = new Score({
        level_ID: levelid,
        username: username,
        score: score,
        date: date
    });
    let oldScore;
    Score.find({ username: username, level_ID: levelid }).sort({ "score": -1 }).limit(1).exec(function (err, oldscore) {
        if (err) return res.json(err);
        if (oldscore[0]) oldScore = oldscore[0].score;
        let msg = `Score of ${score} submitted.`;
        if (oldScore) {
            if (oldScore < newScore.score) {
                msg += `You beat your old score of ${oldScore}!`;
            } else {
                msg += `Your high score is ${oldScore}.`;
            }
        }
        newScore.save(function (err, score) {
            if (err) return res.json(err);
            console.log("Score " + score._id + " saved.");
            return res.json({ success: true, message: msg });
        });
    })

});

// === 'DELETE' ROUTES ===

// DELETE /db/levels/:level_ID will remove a level from the database
//        if its level_ID and author match the level_ID and username
//        provided.
/* Params: {
    String levelid,
    String username
}
*/
router.delete('/db/levels/:level_ID', function (req, res) {
    const levelid = req.body.levelid;
    const username = req.body.username;

    Level.findOneAndDelete({ level_ID: levelid, author: username }, function (req, res) {
        if (err) return res.json(err);
        if (result) {
            res.json({ success: true, message: "Level " + levelid + " has been deleted." });
            return;
        } else if (!result) {
            return res.json({ success: false, message: "ERROR: Level not found. Please try again." });
        }
    });
});

// DELETE /db/accounts/:account will remove a user from the database
//        if its username and password match the username and password
//        provided in the body and request parameter.
/* Params: {
    String username,
    String password, (must match password for this user)
    String account (must match username)
}
*/
router.delete('/db/accounts/:account', function (req, res) {
    const username = req.body.username;
    const accountname = req.params.account;
    const password = hashPassword(req.body.password);
    // Check if the post body and URL param match
    // This does not authenticate anything but is a placeholder
    if (username !== accountname) return res.json({ success: false, message: "Username does not match request" });

    Account.findOneAndDelete({ username: accountname, password: password }, function (err, result) {
        if (err) return res.json(err);
        if (result) {
            delete authTokens[req.cookies.NinjaCelesteAuthToken];
            res.clearCookie('NinjaCelesteAuthToken');
            return res.json({ success: true, message: "Account " + accountname + " has been deleted." });
        } else if (!result) {
            return res.json({ success: false, message: "ERROR: Account not found. Please try again." });
        }
    });
});

// DELETE /db/scores/ will remove a particular score from the database
//          Note this function only removes by the object's _id value
//          So we will need to get its ID via other methods first
/* Params: {
    String scoreid (matches the object's _id value in MongoDB)
}
*/
router.delete("/db/scores/", function (req, res) {
    const scoreid = req.body.scoreid;

    Score.findOneAndDelete({ _id: scoreid }, function (err, result) {
        if (err) return res.json(err);
        if (result) {
            return res.json({ success: true, message: "Score deleted successfully." });
        } else if (!result) {
            return res.json({ success: false, message: "ERROR: Score not found. Please try again." });
        }

    });
});

module.exports = { router, authTokens };
