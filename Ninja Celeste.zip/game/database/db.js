let mongoose = require("mongoose");

// Set up schema object (with the Accounts and Levels schema)
let schema = require("./schema");
//  mongoose connection
mongoose.connect(
    "mongodb://comp4770-user:megaman1@ds263028.mlab.com:63028/comp4770",
    { useNewUrlParser: true, useUnifiedTopology: true }
);

let db = mongoose.connection;

//  error message
db.on("error", console.error.bind(console, "connection error:"));

//  connection reply
db.once("open", () => {
    console.log("Connected to db successfully");
});

//  connection reply on disconnect
db.on("disconnected", function() {
    console.log("Mongoose disconnected");
});

// Export mongoose connection and schemas to the app
module.exports = {
    db,
    schema
};
/**
 *  //  possible functions for database manipulation
 *
 *  addUser(username, email, password#)
 *
 *  getUser(user)
 *
 *  removeUser(user)
 *
 *  addLevel(level)
 *
 *  addCampaignScore(level, score)
 *
 *
 */
