let mongoose = require("mongoose");

// Define Levels schema
let levelSchema = new mongoose.Schema(
    {
        level_ID: { type: String, unique: true },
        author: String,
        data: String,
        highscore_object: Object
    },
    {
        collection: "Levels" //Associate with existing 'Levels' collection
    }
);

// Define Accounts schema
let accountSchema = new mongoose.Schema(
    {
        username: { type: String, unique: true },
        email: { type: String, unique: true },
        password: String,
        campaign_scores: Object,
        campaign_pickups: Object
    },
    {
        collection: "Accounts" //Associate with existing 'Accounts' collection
    }
);

let scoreSchema = new mongoose.Schema(
    {
        level_ID: String,
        username: String,
        score: Number,
        date: Date
    },
    {
        collection: "Scores"
    }
);

// Create models for each schema, so the app can use them easily
let Level = mongoose.model("Level", levelSchema);
let Account = mongoose.model("Account", accountSchema);
let Score = mongoose.model("Score", scoreSchema);

// Export both models
module.exports = {
    Level,
    Account,
    Score
};
