// Asset Manager is here to manage downloading and readying assets
class AssetManager {
    constructor() {
        this.downloadQueue = []; // stuff queued for download
        this.cache = {}; // Maps filepaths to actual images

        // Count successes vs errors
        this.successes = 0;
        this.errors = 0;
    }
    isDone() {
        // Have all queued assets completed downloading? (Successfully or no)
        return this.downloadQueue.length === this.successes + this.errors;
    }
    queueAsset(path) {
        this.downloadQueue.push(path);
    }

    // Download all queued asset files, then call next()
    downloadAssets() {
        // if (this.downloadQueue === 0) next(); // If there's nothing to download, pass
        for (var i = 0; i < this.downloadQueue.length; i++) {
            let path = this.downloadQueue[i];
            const img = new Image();

            // The whole point of this class - we must wait for images to load before using them
            img.addEventListener(
                "load",
                () => {
                    this.successes++;
                    // if (this.isDone()) next();
                },
                false
            );
            img.addEventListener(
                "error",
                () => {
                    this.errors++;
                    // if (this.isDone()) next();
                },
                false
            );
            img.src = path;
            this.cache[path] = img; // Cache the image
        }
    }
    getAsset(path) {
        return this.cache[path];
    }
    getAssets() {
        return this.cache;
    }
}
// Map sprite tags to their actual file paths
const SPRITE_MAP = new Map([
    ["Guard", ["./client/images/mariostand64.png", "npc"]],
    ["Block", ["./client/images/mariostand64.png", "tile"]],
    ["RockUp", ["./client/images/RockUp.png", "tile"]],
    ["RockRight", ["./client/images/RockRight.png", "tile"]],
    ["test", ["./client/images/test.png", "tile"]],
    ["RockLeft", ["./client/images/RockLeft.png", "tile"]],
    ["Player", ["./client/images/megastand64.png", "player"]],
    ["MainMenu", ["./client/images/blue.png", "tile"]],
    ["Button", ["./client/images/green.png", "tile"]],
    ["OptionsMenu", ["./client/images/orange.png", "tile"]],
    ["Red", ["./client/images/redTile.png", "switch"]],
    ["Green", ["./client/images/greenTile.png", "tile"]],
    ["testDoor", ["./client/images/greenTile.png", "door"]],
    ["bbtest", ["./client/images/bbTest.png", "tile"]],
    ["WoodCrate", ["./client/images/crate.png", "tile"]],
    ["Level", ["./client/images/green.png", "tile"]],
    ["SlashLeft", ["./client/images/weapon/slash-effect-png-transparent_left.png", "bullet"]],
    ["SlashRight", ["./client/images/weapon/slash-effect-png-transparent.png", "bullet"]],
    ["Sword", ["./client/images/icon/sv_t_09.png", "bg"]],
    ["Star", ["./client/images/icon/m_t_02.png", "bg"]],
    ["Star", ["./client/images/icon/m_t_02.png", "tile"]],
    ["LeftStanding", ["./client/images/ninja/spr_mc_stand_strip4_left.png", "PlayerStanding", 4]],
    ["RightStanding", ["./client/images/ninja/spr_mc_stand_strip4.png", "PlayerStanding", 4]],
    ["LeftWalk", ["./client/images/ninja/spr_mc_walk_strip4_left.png", "PlayerWalk", 4]],
    ["RightWalk", ["./client/images/ninja/spr_mc_walk_strip4.png", "PlayerWalk", 4]],
    ["LeftJump", ["./client/images/ninja/spr_mc_jmp_strip6_left.png", "PlayerJump", 6]],
    ["RightJump", ["./client/images/ninja/spr_mc_jmp_strip6.png", "PlayerJump", 6]],
    ["RightWall", ["./client/images/ninja/spr_mc_climbon_strip4.png", "PlayerWall", 4]],
    ["LeftWall", ["./client/images/ninja/spr_mc_climbon_strip4_left.png", "PlayerWall", 4]],
    ["DoorActive", ["./client/images/DoorActive.png", "door", 18]],
    ["Door", ["./client/images/DoorClosed.png", "door"]],
    ["DoorOpen", ["./client/images/DoorOpen.png", "door"]],
    ["Overworld", ["./client/images/background.png", "overworld"]],
    ["Drone", ["./client/images/drone.png", "npc"]],
    ["Turret", ["./client/images/greenTile.png", "npc"]],
    ["Gun", ["./client/images/bbTest.png", "bullet"]],
    ["Level", ["./client/images/greenTile.png", "tile"]],
    ["SnowRockCEN0", ["./client/images/SnowRock/SnowRockCEN0.png", "bg"]],
    ["SnowRockCEN1", ["./client/images/SnowRock/SnowRockCEN1.png", "bg"]],
    ["SnowRockCEN2", ["./client/images/SnowRock/SnowRockCEN2.png", "bg"]],
    ["SnowRockCEN3", ["./client/images/SnowRock/SnowRockCEN3.png", "bg"]],
    ["SnowRockCEN4", ["./client/images/SnowRock/SnowRockCEN4.png", "bg"]],
    ["SnowRockCEN5", ["./client/images/SnowRock/SnowRockCEN5.png", "bg"]],
    ["SnowRockCEN6", ["./client/images/SnowRock/SnowRockCEN6.png", "bg"]],
    ["SnowRockCEN7", ["./client/images/SnowRock/SnowRockCEN7.png", "bg"]],
    ["SnowRockCEN8", ["./client/images/SnowRock/SnowRockCEN8.png", "bg"]],
    ["SnowRockCEN9", ["./client/images/SnowRock/SnowRockCEN9.png", "bg"]],
    ["SnowRockCEN10", ["./client/images/SnowRock/SnowRockCEN10.png", "bg"]],
    ["SnowRockBLK0", ["./client/images/SnowRock/SnowRockBLK0.png", "bg"]],
    ["SnowRockCEN11", ["./client/images/SnowRock/SnowRockCEN11.png", "bg"]],
    ["SnowRockLEF0", ["./client/images/SnowRock/SnowRockLEF0.png", "tile"]],
    ["SnowRockLEF1", ["./client/images/SnowRock/SnowRockLEF1.png", "tile"]],
    ["SnowRockLEF2", ["./client/images/SnowRock/SnowRockLEF2.png", "tile"]],
    ["SnowRockLEF3", ["./client/images/SnowRock/SnowRockLEF3.png", "tile"]],
    ["SnowRockRIG0", ["./client/images/SnowRock/SnowRockRIG0.png", "tile"]],
    ["SnowRockRIG1", ["./client/images/SnowRock/SnowRockRIG1.png", "tile"]],
    ["SnowRockRIG2", ["./client/images/SnowRock/SnowRockRIG2.png", "tile"]],
    ["SnowRockRIG3", ["./client/images/SnowRock/SnowRockRIG3.png", "tile"]],
    ["SnowRockTOP0", ["./client/images/SnowRock/SnowRockTOP0.png", "tile"]],
    ["SnowRockTOP1", ["./client/images/SnowRock/SnowRockTOP1.png", "tile"]],
    ["SnowRockTOP2", ["./client/images/SnowRock/SnowRockTOP2.png", "tile"]],
    ["SnowRockTOP3", ["./client/images/SnowRock/SnowRockTOP3.png", "tile"]],
    ["SnowRockBOT0", ["./client/images/SnowRock/SnowRockBOT0.png", "tile"]],
    ["SnowRockBOT1", ["./client/images/SnowRock/SnowRockBOT1.png", "tile"]],
    ["SnowRockBOT2", ["./client/images/SnowRock/SnowRockBOT2.png", "tile"]],
    ["SnowRockBOT3", ["./client/images/SnowRock/SnowRockBOT3.png", "tile"]],
    ["SnowRockTRC0", ["./client/images/SnowRock/SnowRockTRC0.png", "tile"]],
    ["SnowRockTRC1", ["./client/images/SnowRock/SnowRockTRC1.png", "tile"]],
    ["SnowRockTRC2", ["./client/images/SnowRock/SnowRockTRC2.png", "tile"]],
    ["SnowRockTRC3", ["./client/images/SnowRock/SnowRockTRC3.png", "tile"]],
    ["SnowRockTLC0", ["./client/images/SnowRock/SnowRockTLC0.png", "tile"]],
    ["SnowRockTLC1", ["./client/images/SnowRock/SnowRockTLC1.png", "tile"]],
    ["SnowRockTLC2", ["./client/images/SnowRock/SnowRockTLC2.png", "tile"]],
    ["SnowRockTLC3", ["./client/images/SnowRock/SnowRockTLC3.png", "tile"]],
    ["SnowRockBRC0", ["./client/images/SnowRock/SnowRockBRC0.png", "tile"]],
    ["SnowRockBRC1", ["./client/images/SnowRock/SnowRockBRC1.png", "tile"]],
    ["SnowRockBRC2", ["./client/images/SnowRock/SnowRockBRC2.png", "tile"]],
    ["SnowRockBRC3", ["./client/images/SnowRock/SnowRockBRC3.png", "tile"]],
    ["SnowRockBLC0", ["./client/images/SnowRock/SnowRockBLC0.png", "tile"]],
    ["SnowRockBLC1", ["./client/images/SnowRock/SnowRockBLC1.png", "tile"]],
    ["SnowRockBLC2", ["./client/images/SnowRock/SnowRockBLC2.png", "tile"]],
    ["SnowRockBLC3", ["./client/images/SnowRock/SnowRockBLC3.png", "tile"]],
    ["SnowRockBRI0", ["./client/images/SnowRock/SnowRockBRI0.png", "tile"]],
    ["SnowRockBLI0", ["./client/images/SnowRock/SnowRockBLI0.png", "tile"]],
    ["SnowRockTRI0", ["./client/images/SnowRock/SnowRockTRI0.png", "tile"]],
    ["SnowRockTLI0", ["./client/images/SnowRock/SnowRockTLI0.png", "tile"]],
    ["StoneBrickCEN0", ["./client/images/StoneBrick/StoneBrickCEN0.png", "bg"]],
    ["StoneBrickCEN1", ["./client/images/StoneBrick/StoneBrickCEN1.png", "bg"]],
    ["StoneBrickCEN2", ["./client/images/StoneBrick/StoneBrickCEN2.png", "bg"]],
    ["StoneBrickCEN3", ["./client/images/StoneBrick/StoneBrickCEN3.png", "bg"]],
    ["StoneBrickCEN4", ["./client/images/StoneBrick/StoneBrickCEN4.png", "bg"]],
    ["StoneBrickCEN5", ["./client/images/StoneBrick/StoneBrickCEN5.png", "bg"]],
    ["StoneBrickCEN6", ["./client/images/StoneBrick/StoneBrickCEN6.png", "bg"]],
    ["StoneBrickCEN7", ["./client/images/StoneBrick/StoneBrickCEN7.png", "bg"]],
    ["StoneBrickCEN8", ["./client/images/StoneBrick/StoneBrickCEN8.png", "bg"]],
    ["StoneBrickCEN9", ["./client/images/StoneBrick/StoneBrickCEN9.png", "bg"]],
    ["StoneBrickCEN10", ["./client/images/StoneBrick/StoneBrickCEN10.png", "bg"]],
    ["StoneBrickBLK0", ["./client/images/StoneBrick/StoneBrickBLK0.png", "bg"]],
    ["StoneBrickCEN11", ["./client/images/StoneBrick/StoneBrickCEN11.png", "bg"]],
    ["StoneBrickLEF0", ["./client/images/StoneBrick/StoneBrickLEF0.png", "tile"]],
    ["StoneBrickLEF1", ["./client/images/StoneBrick/StoneBrickLEF1.png", "tile"]],
    ["StoneBrickLEF2", ["./client/images/StoneBrick/StoneBrickLEF2.png", "tile"]],
    ["StoneBrickLEF3", ["./client/images/StoneBrick/StoneBrickLEF3.png", "tile"]],
    ["StoneBrickRIG0", ["./client/images/StoneBrick/StoneBrickRIG0.png", "tile"]],
    ["StoneBrickRIG1", ["./client/images/StoneBrick/StoneBrickRIG1.png", "tile"]],
    ["StoneBrickRIG2", ["./client/images/StoneBrick/StoneBrickRIG2.png", "tile"]],
    ["StoneBrickRIG3", ["./client/images/StoneBrick/StoneBrickRIG3.png", "tile"]],
    ["StoneBrickTOP0", ["./client/images/StoneBrick/StoneBrickTOP0.png", "tile"]],
    ["StoneBrickTOP1", ["./client/images/StoneBrick/StoneBrickTOP1.png", "tile"]],
    ["StoneBrickTOP2", ["./client/images/StoneBrick/StoneBrickTOP2.png", "tile"]],
    ["StoneBrickTOP3", ["./client/images/StoneBrick/StoneBrickTOP3.png", "tile"]],
    ["StoneBrickBOT0", ["./client/images/StoneBrick/StoneBrickBOT0.png", "tile"]],
    ["StoneBrickBOT1", ["./client/images/StoneBrick/StoneBrickBOT1.png", "tile"]],
    ["StoneBrickBOT2", ["./client/images/StoneBrick/StoneBrickBOT2.png", "tile"]],
    ["StoneBrickBOT3", ["./client/images/StoneBrick/StoneBrickBOT3.png", "tile"]],
    ["StoneBrickTRC0", ["./client/images/StoneBrick/StoneBrickTRC0.png", "tile"]],
    ["StoneBrickTRC1", ["./client/images/StoneBrick/StoneBrickTRC1.png", "tile"]],
    ["StoneBrickTRC2", ["./client/images/StoneBrick/StoneBrickTRC2.png", "tile"]],
    ["StoneBrickTRC3", ["./client/images/StoneBrick/StoneBrickTRC3.png", "tile"]],
    ["StoneBrickTLC0", ["./client/images/StoneBrick/StoneBrickTLC0.png", "tile"]],
    ["StoneBrickTLC1", ["./client/images/StoneBrick/StoneBrickTLC1.png", "tile"]],
    ["StoneBrickTLC2", ["./client/images/StoneBrick/StoneBrickTLC2.png", "tile"]],
    ["StoneBrickTLC3", ["./client/images/StoneBrick/StoneBrickTLC3.png", "tile"]],
    ["StoneBrickBRC0", ["./client/images/StoneBrick/StoneBrickBRC0.png", "tile"]],
    ["StoneBrickBRC1", ["./client/images/StoneBrick/StoneBrickBRC1.png", "tile"]],
    ["StoneBrickBRC2", ["./client/images/StoneBrick/StoneBrickBRC2.png", "tile"]],
    ["StoneBrickBRC3", ["./client/images/StoneBrick/StoneBrickBRC3.png", "tile"]],
    ["StoneBrickBLC0", ["./client/images/StoneBrick/StoneBrickBLC0.png", "tile"]],
    ["StoneBrickBLC1", ["./client/images/StoneBrick/StoneBrickBLC1.png", "tile"]],
    ["StoneBrickBLC2", ["./client/images/StoneBrick/StoneBrickBLC2.png", "tile"]],
    ["StoneBrickBLC3", ["./client/images/StoneBrick/StoneBrickBLC3.png", "tile"]],
    ["StoneBrickBRI0", ["./client/images/StoneBrick/StoneBrickBRI0.png", "tile"]],
    ["StoneBrickBLI0", ["./client/images/StoneBrick/StoneBrickBLI0.png", "tile"]],
    ["StoneBrickTRI0", ["./client/images/StoneBrick/StoneBrickTRI0.png", "tile"]],
    ["StoneBrickTLI0", ["./client/images/StoneBrick/StoneBrickTLI0.png", "tile"]],
    ["SwitchOpen", ["./client/images/SwitchOpen.png", "switch"]],
    ["SwitchClosed", ["./client/images/SwitchClosed.png", "switch"]],
    ["SwitchActive", ["./client/images/SwitchActive.png", "switch", 4]],
    ["Platform", ["./client/images/Platform.png", "tile"]],
    ["GoldHeart", ["./client/images/GoldHeart.png", "tile", 8]],
    ["Overworld", ["./client/images/background.png", "overworld"]],
    ["Heart", ["./client/images/heart.png", "tile"]],
    ["Boss", ["./client/images/megastand64.png", "npc"]]
]);

const ASSET_MANAGER = new AssetManager();
SPRITE_MAP.forEach((value, key, map) => {
    ASSET_MANAGER.queueAsset(value[0]); // Add the sprite filepaths to the queue to download
});

// Download everything in the assets queue, then create the entities
// The string provided here would ideally come from a level file
// Schema is "Tag PositionX PositionY VelocityX VelocityY"
ASSET_MANAGER.downloadAssets();
