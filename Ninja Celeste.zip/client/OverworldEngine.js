let standingOnLevel = 0;
let overworldActive = false;
let startedFromOverworld = false;

// We will just place the player on the most recently completed level
function overworldStart() {
    if ($.isEmptyObject(ACCOUNT)) return; // must be logged in
    overworldActive = true;

    // If we started the last level from the overworld, it's still the most recent level
    if (!startedFromOverworld) {
        standingOnLevel = getMostRecentLevel(ACCOUNT);
    }
    let playerCoords = getCoordsFromLevelID(standingOnLevel);
    loadOverworld(playerCoords);
}

// Campaign levels will have an ID from 0 through 4
// Get the first one that doesn't exist in the player's score list
// The previous one will be the one most recently completed.
function getMostRecentLevel(ACCOUNT) {
    for (let i = 0; i < 5; i++) {
        if (!ACCOUNT || !ACCOUNT.campaign_scores[i]) {
            if (i == 0) return "0"; // Start on first level even if not done
            return i - 1 + ""; // The (+ "") just casts the int to a string
        }
    }
}

// Take level ID, return its x-y coordinates on the overworld map
function getCoordsFromLevelID(levelID) {
    switch (levelID + "") {
        case "0":
            return { x: 3, y: 3 };
        case "1":
            return { x: 5, y: 3 };
        case "2":
            return { x: 7, y: 3 };
        case "3":
            return { x: 9, y: 3 };
        case "4":
            return { x: 11, y: 3 };
        default:
            return { x: 3, y: 3 };
    }
}
function loadOverworld(playerCoords) {
    $.ajax({
        url: "http://localhost:8000/client/campaign/overworld.txt",
        method: "GET",
        success: function (result) {
            loadLevelFromText(result);
            overworldActive = true;
            ENTITY_MANAGER.initializeEntity(
                `Player ${playerCoords.x} ${playerCoords.y} 0 0 {}`
            );
        },
    });
}

function sOverworldInput() {
    let player = ENTITY_MANAGER.getPlayer();
    if (player.state === "running") return; // Input ignored if the player is between nodes
    if (player.state === "ground" && !pressingleft && !pressingright) {
        if (pressingspace && canPressSpace) {
            startedFromOverworld = true;
            loadCampaignLevel(standingOnLevel);
        }
    }
    if (pressingleft && !pressingright) {
        if (standingOnLevel === 0) return; // Already on leftmost level
        player.state = "running";
        standingOnLevel--;
        player.destination = scalarMultiply(
            getCoordsFromLevelID(standingOnLevel),
            64
        );
        // player.destination = {
        //     x: 64 * (getCoordsFromLevelID(standingOnLevel).x - getCoordsFromLevelID(standingOnLevel - 1).x),
        //     y: 64 * (getCoordsFromLevelID(standingOnLevel).y - getCoordsFromLevelID(standingOnLevel - 1).y)
        // }
    } else if (!pressingleft && pressingright) {
        if (standingOnLevel === 4) return; // Already on rightmost level
        player.state = "running";
        standingOnLevel++;
        player.destination = scalarMultiply(
            getCoordsFromLevelID(standingOnLevel),
            64
        );
        // player.destination = {
        //     x: 64 * (getCoordsFromLevelID(standingOnLevel).x - getCoordsFromLevelID(standingOnLevel + 1).x),
        //     y: 64 * (getCoordsFromLevelID(standingOnLevel).y - getCoordsFromLevelID(standingOnLevel + 1).y)
        // }
    } else {
        // if (player.destination) console.log(`${player.destination.x},${player.destination.y} and ${player.position.x}, ${player.position.y}\nLevel ${standingOnLevel} is at ${getCoordsFromLevelID(standingOnLevel).x * 64}, ${getCoordsFromLevelID(standingOnLevel).y * 64}`);
        player.destination = player.position;
        player.state = "ground";
    }
}

function sOverworldMovement() {
    let player = ENTITY_MANAGER.getPlayer();
    if (!player.destination) return;
    player.velocity = scalarMultiply(
        getUnitVector(vectorSubtract(player.destination, player.position)),
        2
    );
    // if (player.destination) console.log(`${player.destination.x},${player.destination.y} and ${player.position.x}, ${player.position.y}\nLevel ${standingOnLevel} is at ${getCoordsFromLevelID(standingOnLevel).x * 64}, ${getCoordsFromLevelID(standingOnLevel).y * 64}`);
    if (player.velocity.x === 0 && player.velocity.y === 0) {
        player.state = "ground";
    }
    player.position.x += player.velocity.x;
    player.position.y += player.velocity.y;
}

function overworldState() {
    if (overworldActive) {
        sOverworldInput();
        sOverworldMovement();
        // Use same animation and rendering procedure as GameEngine
        // sAnimation();
        sRender(ctx);
        if (displayModal) drawModal(ctx);
    }
}
