//returns the overlap of the 2 entity as a delta(x) and delta(y)
function GetOverlap(Entity1, Entity2) {
    if (Entity1.CBoundingBox && Entity2.CBoundingBox) {
        deltax = Math.abs(Entity1.position.x - Entity2.position.x);
        deltay = Math.abs(Entity1.position.y - Entity2.position.y);
        if (Entity1.position.x > Entity2.position.x) {
            BBx = Entity2.CBoundingBox.length;
        }
        else BBx = Entity1.CBoundingBox.length;
        if (Entity1.position.y > Entity2.position.y) {
            BBy = Entity2.CBoundingBox.height;
        }
        else BBy = Entity1.CBoundingBox.height;

        ox = BBx - deltax;
        oy = BBy - deltay;
        return [ox, oy];
    }
    else return [0, 0];
}
//returns the overlap after reversing their movement phase to get previous overlap
function GetPreviousOverlap(Entity1, Entity2) {
    if (Entity1.CBoundingBox && Entity2.CBoundingBox) {
        deltax = Math.abs((Entity1.position.x - Entity1.velocity.x) - (Entity2.position.x - Entity2.velocity.x));
        deltay = Math.abs((Entity1.position.y - Entity1.velocity.y) - (Entity2.position.y - Entity2.velocity.y));
        if (Entity1.position.x > Entity2.position.x) {
            BBx = Entity2.CBoundingBox.length;
        }
        else BBx = Entity1.CBoundingBox.length;
        if (Entity1.position.y > Entity2.position.y) {
            BBy = Entity2.CBoundingBox.height;
        }
        else BBy = Entity1.CBoundingBox.height;

        ox = BBx - deltax;
        oy = BBy - deltay;

        return [ox, oy];
    }
    else return [0, 0];
}

// Returns intercept if line (a,b) intersects with line (c,d)
// Note a,b,c,d are all vectors of the form {x,y}.
function LineIntersect(a, b, c, d) {
    let r = vectorSubtract(b, a);
    let s = vectorSubtract(d, c);
    let rxs = crossProduct(r, s);
    let cma = vectorSubtract(c, a);
    let t = crossProduct(cma, s) / rxs;
    let u = crossProduct(cma, r) / rxs;
    if (t >= 0 && t <= 1 && u >= 0 && u <= 1) return { x: a.x + t * r.x, y: a.y + t * r.y };
    else {
        return false;
    }
}

// If line (v1,v2) intersects with Entity e, 
// Returns the intercept with the blocking edge, (i.e., closest to v1) 
// else returns false
function EntityIntersect(v1, v2, e) {
    // Utility function to find which of two intercepts is closer to v1
    function closer(intercept1, intercept2) {
        if (!intercept1) return intercept2;
        if (!intercept2) return intercept1;
        return (vectorMagnitude(vectorSubtract(v1, intercept1)) < vectorMagnitude(vectorSubtract(v1, intercept2)) ? intercept1 : intercept2);
    }
    if (e.tag === "Block") {
        console.log("BLock");
    }
    let intercept = false;
    // Left side
    // v1, v2, top left corner, bottom left corner
    intercept = LineIntersect(v1, v2,
        e.position,
        { x: e.position.x, y: e.position.y + e.CBoundingBox.height });
    // Top side
    // v1, v2, top left corner, top right corner
    intercept = closer(intercept, LineIntersect(v1, v2,
        e.position,
        { x: e.position.x + e.CBoundingBox.length, y: e.position.y }));
    // Bottom side
    // v1, v2, bottom left corner, bottom right corner
    intercept = closer(intercept, LineIntersect(v1, v2,
        { x: e.position.x, y: e.position.y + e.CBoundingBox.height },
        { x: e.position.x + e.CBoundingBox.length, y: e.position.y + e.CBoundingBox.height }));
    // Right side
    // v1, v2, top right corner, bottom right corner
    intercept = closer(intercept, LineIntersect(v1, v2,
        { x: e.position.x + e.CBoundingBox.length, y: e.position.y },
        { x: e.position.x + e.CBoundingBox.length, y: e.position.y + e.CBoundingBox.height }));
    return intercept;
}
// returns a unit vector in the same direction as the input vector
// If the input vector's magnitude rounds to 0, return vector (0,0)
function getUnitVector(vector) {
    let magnitude = vectorMagnitude(vector);
    if (magnitude <= 0.5) return { x: 0, y: 0 }; // avoid dividing by 0
    return { x: vector.x / magnitude, y: vector.y / magnitude };
}

function vectorMagnitude(vector) {
    return Math.sqrt(vector.x * vector.x + vector.y * vector.y);
}

function vectorSubtract(vec1, vec2) {
    return {
        x: vec1.x - vec2.x,
        y: vec1.y - vec2.y
    }
}

function scalarMultiply(vec, scalar) {
    return {
        x: vec.x * scalar,
        y: vec.y * scalar
    }
}

function crossProduct(vec1, vec2) {
    return vec1.x * vec2.y - vec1.y * vec2.x;
}

function getGridCoordsFromCanvasCoords(x, y) {
    return { x: Math.floor(x / 64), y: Math.floor(y / 64) };
}

function tileIsBlocked(x, y) {
    return ENTITY_MANAGER.TileEntities.find(tile => tile.CBoundingBox.collide === true && tile.position.x / 64 === x && tile.position.y / 64 === y);
}