//Gives an entity health, enabling it to take damage, being destroyed at 0
class CHealth {
    constructor(maxHealth, currentHealth) {
        this.maxHealth = maxHealth || 1;
        this.currentHealth = currentHealth || 1;
    }
    hurt(damage) {
        this.currentHealth -= damage;
        return this.currentHealth < 1;
    }
    heal(damage) {
        this.currentHealth = Math.min(this.currentHealth + damage, this.maxHealth);
    }
}

class CDamage {
    constructor(damage) {
        this.damage = damage || 1;
    }
}

class CAnimation {
    constructor(tag) {
        this.stateMap = [];
        this.animation = null;
        this.imageShift = 0;
        this.currentFrame = 0;
        this.numberOfFrames = 1;
        this.animationSpeed = 15;
        this.animationTimer = 0;
        if (tag == "Player") {
            this.stateMap = new Map([
                ["walk", ["LeftWalk", "RightWalk"]],
                ["ground", ["LeftStanding", "RightStanding"]],
                ["air", ["LeftJump", "RightJump"]],
                ["wall", ["LeftWall", "RightWall"]]
            ]);
        }
        if (tag == "Door") {
            this.stateMap = new Map([
                ["active", ["DoorActive", "DoorActive"]],
                ["closed", ["Door", "Door"]],
                ["open", ["DoorOpen", "DoorOpen"]]
            ]);
        }
        if (tag == "SwitchClosed") {
            this.stateMap = new Map([
                ["active", ["SwitchActive", "SwitchActive"]],
                ["closed", ["SwitchClosed", "SwitchClosed"]],
                ["open", ["SwitchOpen", "SwitchOpen"]]
            ]);
        }
        if (tag == "GoldHeart") {
            this.stateMap = new Map([
                ["open", ["GoldHeart", "GoldHeart"]]
            ])
        }
    }
    setAnimation(animName) {
        if (this.animation == ASSET_MANAGER.cache[SPRITE_MAP.get(animName)[0]]) return;
        this.animation = ASSET_MANAGER.cache[SPRITE_MAP.get(animName)[0]];
        this.numberOfFrames = SPRITE_MAP.get(animName)[2];
        this.currentFrame = 0;
        this.imageShift = Math.ceil(this.animation.width / this.numberOfFrames);
        this.animationTimer = 0;
    }
    update() {
        if (this.animationTimer++ > this.animationSpeed) {
            this.currentFrame++;
            this.animationTimer = 0;
            if (this.currentFrame >= this.numberOfFrames) {
                if (this.callback) this.callback();
                this.currentFrame = 0;
            }
        }
    }
}

// Defines an AI type for the entity, patrol, fly, ect.
// no AI, doesnt move or react
// patrol: follow path of points going to next one in the list and repeating, moving straight to it with no gravity or tilecollision(maybe?)
// follow: moves toward player to attack if line of sight, otherwise homebase.
// sentry: stays still and shoots at player if line of sight is made.
class CAI {
    constructor(aiType, waypoints, nextWaypoint) {
        this.aiType = aiType
        this.waypoints = waypoints || [];
        this.nextWaypoint = nextWaypoint || 0;
        this.path = [];
        this.hunting = false;
        this.home = {};
        this.patrollingForward = true;
        this.lastDropped = false;
        this.lastFired = false;
        this.watchingPlayer = false;
        this.lookingAt = false;
    }
    isAtNextWaypoint(position) {
        if (this.aiType === "patrol") {
            return (vectorMagnitude(vectorSubtract(this.waypoints[this.nextWaypoint], position)) < 1);
        }
        if (this.aiType === "follow") {
            if (!this.path.length > 0) return;
            return (vectorMagnitude(vectorSubtract(scalarMultiply(this.next(), 64), position)) < 1);
        }
    }
    lookAt(x, y) {
        this.lookingAt = { x: x, y: y };
    }
    lookingAtEntity(npc, entity) {
        return EntityIntersect(npc.center(), this.lookingAt, player);
    }
    canDrop() {
        if (this.lastDropped === false) return true;
        return new Date().getTime() - this.lastDropped.getTime() > 5000;
    }
    canShoot() {
        if (this.lastFired === false) return true;
        return new Date().getTime() - this.lastFired.getTime() > 1000;
    }
    cycleWaypoint() {
        if (this.aiType === "patrol") {
            if (this.patrollingForward) {
                if (this.nextWaypoint < this.waypoints.length - 1) {
                    this.nextWaypoint++;
                } else {
                    this.patrollingForward = !this.patrollingForward;
                }
            } else {
                if (this.nextWaypoint > 0) {
                    this.nextWaypoint--;
                } else {
                    this.patrollingForward = !this.patrollingForward;
                }
            }
        }
        if (this.aiType === "follow") {
            if (this.path.length < 2) {
                this.path.pop();
                return;
            }
            let currentNext = this.path[this.path.length - 1];
            let maybeNext = this.path[this.path.length - 2];
            let v = vectorSubtract(currentNext, maybeNext);
            if (v.x === 0 || v.y === 0) {
                this.path.pop();
            } else {
                // if the tile to the left/right is blocked, route via top/bottom
                if (tileIsBlocked(currentNext.x + v.x, currentNext.y) && !tileIsBlocked(currentNext.x, currentNext.y + v.y)) {
                    this.path[this.path.length - 1] = { x: currentNext.x, y: currentNext.y + v.y };
                } else if (!tileIsBlocked(currentNext.x + v.x, currentNext.y) && tileIsBlocked(currentNext.x, currentNext.y + v.y)) {
                    this.path[this.path.length - 1] = { x: currentNext.x + v.x, y: currentNext.y };
                } else {
                    this.path.pop();
                }
            }
        }
    }
    drop(npc) {
        ENTITY_MANAGER.createEntity("Turret", scalarMultiply(npc.position, 1 / 64), { x: 0, y: 0 }, "CLifespan 3000 CAI sentry CWeapon Gun 0 0 CWeight 2 CBoundingBox 64 64 true false");
        this.lastDropped = new Date();
    }
    goHome(npc) {
        let npcPos = getGridCoordsFromCanvasCoords(npc.position.x, npc.position.y);
        this.path = astar(npcPos, this.home);
    }
    hunt(npc, player) {
        // if (this.path.length > 0) return;
        let playerPos = getGridCoordsFromCanvasCoords(player.position.x, player.position.y);
        let npcPos = getGridCoordsFromCanvasCoords(npc.position.x, npc.position.y);
        this.path = astar(npcPos, playerPos);
        if (this.path === undefined) {
            this.goHome(npc);
            this.hunting = false;
        } else {
            this.hunting = new Date();
        }
    }
    isHome(position) {
        return (vectorMagnitude(vectorSubtract(position, this.home)) < 1);
    }
    isHunting() {
        if (this.hunting === false) return false;
        return new Date().getTime() - this.hunting.getTime() < 50;
    }
    lineOfSight(npc, player) {
        return vectorSubstract(npc.position, player.position);
    }
    next() {
        return this.path[this.path.length - 1];
    }
    makePatrolPath(startx, starty) {
        let newPath = [];
        for (var i = 0; i < this.waypoints.length - 1; i++) {
            newPath = newPath.concat(astar(this.waypoints[i], this.waypoints[i + 1]));
        }
        newPath.push(this.waypoints[0]);
        if (!this.waypoints.find(waypoint => waypoint.x == startx && waypoint.y == starty)) newPath.push({ x: startx, y: starty });
        this.waypoints = newPath.map(wp => scalarMultiply(wp, 64)).reverse();
    }
    shootAt(npc, entity) {
        npc.facing = Math.sign(vectorSubtract(entity.position, npc.position).x);
        if (this.canShoot()) {
            npc.CWeapon.use();
        }
    }
}

//Defines a bounding box for collision
class CBoundingBox {
    constructor(length, height, collide, blocksVision) {
        this.length = length;
        this.height = height;
        if (collide === "true") this.collide = true;
        if (collide === "false") this.collide = false;
        if (blocksVision === "true") this.blocksVision = true;
        if (blocksVision === "false") this.blocksVision = false;
    }
}

//Makes the entity hold another  entity, creating at the entitys location when destroyed
class CDropItem {
    constructor(dropEntity) {
        this.dropEntity = dropEntity
    }
}

//Makes an entity get destroyed when touched and add to a collectable  total based on type
//collectabletype is location in collectable table it should be deposited.
class CCollectable {
    constructor(collectableType, arg1, arg2, arg3) {
        this.collectableType = collectableType;

        // Is a weapon pickup
        if (collectableType === 1) {
            this.tag = arg1;
            this.ammo = arg2;
            this.maxAmmo = arg3;
        }
        // Is a health pickup
        if (collectableType === 2) {
            this.health = arg1;
        }
    }
}

// whether or not entity is affected by keyboard input
class CControllable {
    constructor(max) {
        this.jumpLeft = max;
        this.jumpMax = max;
        this.canJump = true;
        this.canClimb = true;
        this.climbDir = 1;
        this.canPressE = true;
    }
}

// whether the entity is pushable or not. anything with weight also has gravity.
//0: not effected by gravity
//1: effected by gravity but cant activate buttons or switches
//2: effected by gravity and can activate buttons/switches
//3: same as 2 but too heavy to push by player
class CWeight {
    constructor(weight) {
        this.weight = weight;
    }
}

class CLifespan {
    constructor(lifespan) {
        this.born = new Date();
        this.lifespan = lifespan;
    }
    isTooOld() {
        return (new Date().getTime() - this.born.getTime() > this.lifespan);
    }
}

class CWeapon {
    constructor(weaponName, ammo, maxAmmo, shooter) {
        this.weaponName = weaponName;
        this.ammo = ammo;
        this.maxAmmo = maxAmmo;
        this.icon = ASSET_MANAGER.cache[SPRITE_MAP.get(weaponName)[0]];
        this.shooter = shooter;
        this.lastUsed = new Date();
    }
    getLastUsed() {
        return this.lastUsed.getTime();
    }
    use() {
        if (this.maxAmmo === '0' || this.ammo > 0) {
            if (this.ammo > 0) {
                this.ammo--;
            }
            if (this.weaponName === "Sword") {
                if (!this.shooter) return;
                // Sword can be used once every half-second
                if (new Date().getTime() - this.getLastUsed() < 500) return;
                this.lastUsed = new Date();
                let xdiff = this.shooter.sprite.width * 0.75 * this.shooter.facing;
                let ydiff = this.shooter.sprite.height - ASSET_MANAGER.cache[SPRITE_MAP.get("SlashRight")[0]].height - 5;
                let bulletPosition = { x: this.shooter.position.x + xdiff, y: this.shooter.position.y + ydiff };
                if (this.shooter.facing > 0) {
                    ENTITY_MANAGER.createEntity("SlashRight", scalarMultiply(bulletPosition, 1 / 64), this.shooter.velocity, "CLifespan 500 CBoundingBox 64 40 false false CDamage 10");
                } else if (this.shooter.facing < 0) {
                    ENTITY_MANAGER.createEntity("SlashLeft", scalarMultiply(bulletPosition, 1 / 64), this.shooter.velocity, "CLifespan 500 CBoundingBox 64 40 false false CDamage 10");
                }
            }
            if (this.weaponName === "Star") {
                if (!this.shooter) return;
                if (new Date().getTime() - this.getLastUsed() < 500) return;
                this.lastUsed = new Date();
                let xdiff = this.shooter.sprite.width * 0.75 * this.shooter.facing;
                let ydiff = this.shooter.sprite.height - ASSET_MANAGER.cache[SPRITE_MAP.get("SlashRight")[0]].height - 5;
                let bulletPosition = { x: this.shooter.position.x + xdiff, y: this.shooter.position.y + ydiff };
                let bulletVelocity = { x: 10 * this.shooter.facing, y: 0 };
                if (this.shooter.facing > 0) {
                    ENTITY_MANAGER.createEntity("SlashRight", scalarMultiply(bulletPosition, 1 / 64), bulletVelocity, "CLifespan 500 CBoundingBox 8 8 false false CDamage 3");
                } else {
                    ENTITY_MANAGER.createEntity("SlashLeft", scalarMultiply(bulletPosition, 1 / 64), bulletVelocity, "CLifespan 500 CBoundingBox 8 8 false false CDamage 3");
                }
            }
            if (this.weaponName === "Gun") {
                if (!this.shooter) return;
                if (new Date().getTime() - this.getLastUsed() < 500) return;
                this.lastUsed = new Date();
                let xdiff = this.shooter.sprite.width * 0.75 * this.shooter.facing;
                let ydiff = this.shooter.sprite.height - ASSET_MANAGER.cache[SPRITE_MAP.get("SlashRight")[0]].height - 5;
                let bulletPosition = { x: this.shooter.position.x + xdiff, y: this.shooter.position.y + ydiff };
                let bulletVelocity = { x: 5 * this.shooter.facing, y: 0 };
                if (this.shooter.facing > 0) {
                    ENTITY_MANAGER.createEntity("Gun", scalarMultiply(bulletPosition, 1 / 64), bulletVelocity, "CLifespan 2000 CBoundingBox 8 8 false false CDamage 10");
                } else {
                    ENTITY_MANAGER.createEntity("Gun", scalarMultiply(bulletPosition, 1 / 64), bulletVelocity, "CLifespan 2000 CBoundingBox 8 8 false false CDamage 10");
                }
            }
        }
    }
}

//connected to any entity that can activate via switch.
class CActivate {
    constructor(id, type) {
        this.id = id;
        this.type = type;
        this.toggle = false;
    }
}

//component to detect what state the entity is in to select the correct texture.
//air:in the air/mid-jump
//ground:in contact with ground/idle
//running: moving left or right
//wall: holding a wall
class CState {
    constructor(state) {
        this.state = state;
    }
}

//component to dictate the score for defeating an enemy, or for collecting a pickup
class CScore {
    constructor(score) {
        this.score = score || 0;
    }
    getScore() {
        return this.score;
    }
}





//TODO Hitbox as seperate component?     no we will use bounding box for hitbox
