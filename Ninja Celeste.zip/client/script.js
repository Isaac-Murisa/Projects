// ===============================
// ==== INITIALIZE EVERYTHING ====
// ===============================

// Initialize drawing context
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

// Make the asset manager and sprite map available to entity manager
const ENTITY_MANAGER = new EntityManager();

// Make the player's username and campaign progress available to client
let ACCOUNT = {};

// TODO: REMEMBER TO REMOVE THIS WHEN DONE TESTING
// ACCOUNT = {
//     username: "passwordispassword",
//     campaign_scores: {
//         "0": "500",
//         "1": "1000"
//     },
//     campaign_pickups: {
//         "coins": "99",
//         "bullets": "50"
//     }
// }

// Additionally, track player's current status during gameplay
let PLAYER_STATUS = {};
let listenersAdded = false;
function addInputListeners() {
    if (listenersAdded) return;
    listenersAdded = true;
    //Event listeners for key presses and releases
    document.addEventListener('keydown', function (event) {
        // left arrow key
        if (event.keyCode == 37 || event.keyCode == 65) {
            if (!MENU_MANAGER.menuStack[0]) event.preventDefault();
            pressingleft = true;
        }
        // right arrow key
        else if (event.keyCode == 39 || event.keyCode == 68) {
            if (!MENU_MANAGER.menuStack[0]) event.preventDefault();
            pressingright = true;
        }
        // down arrow key
        else if (event.keyCode == 40 || event.keyCode == 83) {
            if (!MENU_MANAGER.menuStack[0]) event.preventDefault();
            pressingdown = true;
        }
        // up arrow key
        else if (event.keyCode == 38 || event.keyCode == 87) {
            if (!MENU_MANAGER.menuStack[0]) event.preventDefault();
            pressingup = true;
        }
        //space key
        else if (event.keyCode == 32) {
            if (!MENU_MANAGER.menuStack[0]) event.preventDefault();
            playJumpSounds();
            pressingspace = true;
            //ENTITY_MANAGER.player.CControllable.canJump = false;
        }
        // shift key
        else if (event.keyCode == 16) {
            if (!MENU_MANAGER.menuStack[0]) event.preventDefault();
            pressingshift = true;
        }
        // X key
        else if (event.keyCode == 88) {
            if (!MENU_MANAGER.menuStack[0]) event.preventDefault();
            playBulletSound();
            pressingx = true;
        }
        // F key
        else if (event.keyCode == 70) {
            if (!MENU_MANAGER.menuStack[0]) event.preventDefault();
            pressingf = true;
        }
        else if (event.keyCode == 69) {
            if (!MENU_MANAGER.menuStack[0]) event.preventDefault();

            pressinge = true;
        }
    });
    document.addEventListener('keyup', function (event) {
        // left arrow key
        if (event.keyCode == 37 || event.keyCode == 65) {
            event.preventDefault();
            pressingleft = false;
        }
        // right arrow key
        else if (event.keyCode == 39 || event.keyCode == 68) {
            event.preventDefault();
            pressingright = false;
        }
        // down arrow key
        else if (event.keyCode == 40 || event.keyCode == 83) {
            event.preventDefault();
            pressingdown = false;
        }
        // up arrow key
        else if (event.keyCode == 38 || event.keyCode == 87) {
            event.preventDefault();
            pressingup = false;
        }
        //space key
        else if (event.keyCode == 32) {
            event.preventDefault();
            pressingspace = false;
            canPressSpace = true;
            ENTITY_MANAGER.player.CControllable.canJump = true;
        }
        else if (event.keyCode == 69) {
            event.preventDefault();

            ENTITY_MANAGER.player.CControllable.canPressE = true;
            pressinge = false;
        }
        // esc key
        else if (event.keyCode == 27) {
            if (MENU_MANAGER.menuStack[0]) {
                // If a menu is open, close the current menu
                if (MENU_MANAGER.peekTop() !== mainMenu) MENU_MANAGER.closeMenu();
            } else {
                // If not, open the pause menu
                ENTITY_MANAGER.lastPaused = Date.now();
                MENU_MANAGER.openMenu(pauseMenu);
            }
        }
        // shift key
        else if (event.keyCode == 16) {
            event.preventDefault();
            pressingshift = false;
            ENTITY_MANAGER.player.CControllable.canClimb = true;
        }
        // X key
        else if (event.keyCode == 88) {
            event.preventDefault();
            pressingx = false;
            canPressX = true;
        }
        // F key
        else if (event.keyCode == 70) {
            event.preventDefault();
            pressingf = false;
            canPressF = true;
        }
    });

    document.addEventListener('click', function (e) {
        let top = MENU_MANAGER.peekTop();
        if (!top) {
            let xcoord = e.pageX - $('#canvas').offset().left;
            let ycoord = e.pageY - $('#canvas').offset().top;
            let camx = xcoord + camera.left;
            let camy = ycoord + camera.top;
            let gridcoords = getGridCoordsFromCanvasCoords(camx, camy);
            console.log(gridcoords.x + "," + gridcoords.y);
            return;
        } // If no menu is open, clicking does nothing
        for (let i = 0; i < top.buttons.length; i++) {
            // convert the X and Y mouse position to be relative to canvas
            let xcoord = e.pageX - $('#canvas').offset().left;
            let ycoord = e.pageY - $('#canvas').offset().top;
            if (top.buttons[i].pointWithin(xcoord, ycoord)) {
                if (top.buttons[i] instanceof Slider) continue;
                top.buttons[i].press(e);
                break;
            }
        }
    });
    document.addEventListener('mousemove', function (e) {
        let top = MENU_MANAGER.peekTop();
        if (!top) return;
        for (let i = 0; i < top.buttons.length; i++) {
            let xcoord = e.pageX - $('#canvas').offset().left;
            let ycoord = e.pageY - $('#canvas').offset().top;

            // For sliders, the mouse can be off the element but still be dragging the slider
            // So we just check to see if they're currently being dragged
            if (top.buttons[i] instanceof Slider && top.buttons[i].state === "dragged") {
                top.buttons[i].press(xcoord);
                break;
            }

            // Handle other buttons
            if (top.buttons[i].pointWithin(xcoord, ycoord)) {
                if (top.buttons[i].state === "pressed") continue;
                top.buttons[i].state = "hovered";
            } else {
                top.buttons[i].state = "normal";
            }
        }
    });
    document.addEventListener('mousedown', function (e) {
        let top = MENU_MANAGER.peekTop();
        if (!top) return;
        for (let i = 0; i < top.buttons.length; i++) {
            let xcoord = e.pageX - $('#canvas').offset().left;
            let ycoord = e.pageY - $('#canvas').offset().top;
            if (top.buttons[i].pointWithin(xcoord, ycoord)) {
                // For sliders, begin dragging
                if (top.buttons[i] instanceof Slider) {
                    top.buttons[i].state = "dragged";
                    top.buttons[i].press(xcoord);
                    break;
                } else {
                    top.buttons[i].state = "pressed";
                }
            }
        }
    });
    document.addEventListener('mouseup', function (e) {
        let top = MENU_MANAGER.peekTop();
        if (!top) return;
        for (let i = 0; i < top.buttons.length; i++) {
            let xcoord = e.pageX - $('#canvas').offset().left;
            let ycoord = e.pageY - $('#canvas').offset().top;
            // Return all buttons and sliders to a non-clicked state
            if (top.buttons[i].pointWithin(xcoord, ycoord)) {
                top.buttons[i].state = "hovered";
            } else {
                top.buttons[i].state = "normal";
            }
        }
    });
}

// === EXAMPLE OF LOADING LEVEL FROM THE DATABASE ===
// $.ajax({
//     url: 'http://localhost:8000/db/levels/1',
//     method: "GET",
//     success: function (result) {
//         ENTITY_MANAGER.initializeEntities(result.data.split(",")); console.log(result);
//     }
// });


function init() {
    // Start with Main Menu open
    MENU_MANAGER.menuStack = [mainMenu];
    addInputListeners();
    // Loading test level in-line
    // ENTITY_MANAGER.initializeEntities(["RockUp 6 5 0 0 {}", "RockUp 5 5 0 0 {}"]);

    requestAnimationFrame(gameLoop);
}

// FOR TESTING THE LOGIN SYSTEM, COMMENT OUT THE BELOW LINE
// YOU MUST ALSO SEARCH "UNCOMMENT" IN LOGIN.JS AND UNCOMMENT
// THE CORRESPONDING LINES !!!

// init();
