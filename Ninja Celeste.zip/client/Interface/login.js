/**
 * User Login and Signup Module
 * 
 * Purpose:
 *  - This module is responsible for handling the signup and login pop-up div tags.
 *  - Responsible for login and sign up requests.
 */

// Game cookie

// check if the user has logged in before
// ============Uncomment to test the login system==================
window.onload = function checkUser() {
    $.get('/checkCookie', function (res) {
        if (res.success) {
            storePlayer(res);
            closeForms();
            init();
        }
        else {
            openLogin();
        }
    });
};

// get form information and process user login request
function Login() {

    // get login form values
    // post data to server
    $.post({
        traditional: true,
        url: '/login',
        contentType: 'application/json',
        data: JSON.stringify({
            'username': document.getElementById("username").value,
            'password': document.getElementById("password").value
        }),
        dataType: 'json',
    })
        // handle request errors and success
        .done(function (res) {
            if (!res.success) {
                openLogin();
                alert(res.message);
            }
            else {
                storePlayer(res);
                closeForms();
                init();
            }
        })
        .fail(function (res) {
            openLogin();
            console.log(res);
        });
}

// get user signup information and create user.
function Signup() {

    // get signup form values
    // post data to server
    $.post({
        traditional: true,
        url: '/db/addUser',
        contentType: 'application/json',
        data: JSON.stringify({
            'username': document.getElementById("enterUsername").value,
            'password': document.getElementById("createPassword").value,
            'confirmPassword': document.getElementById("retypePassword").value,
            'email': document.getElementById("enterEmail").value
        }),
        dataType: 'json',
    })
        // handle responses from server and alert user.
        // also reopen forms if user needs to correct errors e.g. when email is already taken
        .done(function (res) {
            if (!res.success) {
                openSignup();
                alert(res.message);
            }
            else {
                storePlayer(res);
                closeForms();
            }
        })
        .fail(function (res) {
            openLogin();
            console.log(res);
        });
}

/**
 * Delete Account
 */
function DeleteAcc() {
    $.ajax({
        url: '/db/accounts/' + document.getElementById("dusername").value,
        method: 'DELETE',
        contentType: 'application/json',
        data: JSON.stringify({
            'username': document.getElementById("dusername").value,
            'password': document.getElementById("dpassword").value
        }),
        dataType: 'json',
        success: function(res) {
            console.log("Deleted");
            alert("Account has been Deleted.");
            openLogin();
        },
        error: function(res) {
            console.log(res);
        }
    });
}

function addLevel() {
    $.post({
        traditional: true,
        url: '/db/addLevel',
        contentType: 'application/json',
        data: JSON.stringify({
            'levelid': document.getElementById("levelid").value,
            'data': document.getElementById("level").value
        }),
        dataType: 'json',
    })
    // handle request errors and success
    .done(function (res) {
        console.log("Level added");
        closeAddLevelForm();
    })
    .fail(function (res) {
        console.log(res);
    });
}


// open/show login form
function openLogin() {
    document.getElementById("canvas").style.display = "none";
    document.getElementById("loginDiv").style.display = "block";
    document.getElementById("signupDiv").style.display = "none";
    document.getElementById("deleteDiv").style.display = "none";
}

// show/open signup form 
function openSignup() {
    document.getElementById("canvas").style.display = "none";
    document.getElementById("signupDiv").style.display = "block";
    document.getElementById("loginDiv").style.display = "none";
    document.getElementById("deleteDiv").style.display = "none";
}

// show/open Deleting Form 
function openDeleteForm() {
    document.getElementById("canvas").style.display = "none";
    document.getElementById("signupDiv").style.display = "none";
    document.getElementById("loginDiv").style.display = "none";
    document.getElementById("deleteDiv").style.display = "block";
}

function openAddLevelForm() {
    document.getElementById("canvas").style.display = "none";
    document.getElementById("addLevel").style.display = "block";
}

function closeAddLevelForm() {
    document.getElementById("canvas").style.display = "block";
    document.getElementById("addLevel").style.display = "none";
}

function cancelDelete() {
    document.getElementById("canvas").style.display = "block";
    document.getElementById("deleteDiv").style.display = "none";
}

// hide/close signup and login form, after successful login
function closeForms() {
    document.getElementById("canvas").style.display = "block";
    document.getElementById("signupDiv").style.display = "none";
    document.getElementById("loginDiv").style.display = "none";
    document.getElementById("deleteDiv").style.display = "none";
    // Uncomment the below line to diable login system.
    init();
}

function storePlayer(res) {
    if (res.token) {
        res = res.token;
    }
    console.log(res);
    ACCOUNT.username = res.username;
    ACCOUNT.campaign_pickups = res.campaign_pickups;
    ACCOUNT.campaign_scores = res.campaign_scores;
}