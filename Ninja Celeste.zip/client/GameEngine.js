
class Camera {
    constructor(width, height, left, top, safeBorderX, safeBorderY) {
        this.width = width || 0;
        this.height = height || 0;
        this.left = left || 0;
        this.top = top || 0;


        // Determine how far the player can go without moving the camera
        // Default: player is always centered in canvas
        this.safeBorderX = safeBorderX || this.width / 2;
        this.safeBorderY = safeBorderY || this.height / 2;
    }
    // pan(axis,amount) {
    //     if (axis === "x") this.left += amount;
    //     if (axis === "y") this.top -= amount;
    // }
    set(x, y) {
        this.left = x;
        this.top = y;
    }
    follow(entity) {
        // convert entity's world position to camera position
        let cameraX = entity.position.x - this.left;
        let cameraY = entity.position.y - this.top;

        // adjust camera so entity is within safe zone
        // right
        if (cameraX > this.width - this.safeBorderX) {
            this.left += cameraX + this.safeBorderX - this.width;
        }
        // left
        if (cameraX < this.safeBorderX) {
            this.left += cameraX - this.safeBorderX;
        }
        // down
        if (cameraY > this.height - this.safeBorderY) {
            this.top += cameraY + this.safeBorderY - this.height;
        }
        // up
        if (cameraY < this.safeBorderY) {
            this.top += cameraY - this.safeBorderY;
        }

    }
}

// Handle Entity AI moves and attacks
function sAI() {
    player = ENTITY_MANAGER.player;
    let AIs = ENTITY_MANAGER.NPCEntities.filter(e => e.CAI);
    AIs = AIs.concat(ENTITY_MANAGER.TileEntities.filter(e => e.CAI));
    for (var i = 0; i < AIs.length; i++) {
        if (AIs[i].CAI.aiType === "patrol") {
            if (AIs[i].CAI.isAtNextWaypoint(AIs[i].position)) {
                AIs[i].CAI.cycleWaypoint();
            }
            if (AIs[i].tag === "Drone") {
                let drone = AIs[i];
                if (drone.CAI.lookingAt === false || !drone.CAI.lookingAtEntity(drone, player)) {
                    drone.CAI.lookAt(drone.facing * (drone.position.x + 400), drone.position.y + 400);
                }
                let blockers = ENTITY_MANAGER.TileEntities.filter(e => e.CBoundingBox.blocksVision === true);
                let blocked = false;
                let closestIntersect = { x: drone.position.x + 320, y: drone.position.y + 320 };

                for (var j = 0; j < blockers.length; j++) {

                    if (!player) {
                        console.log("HOW?!");
                    }
                    let intersect = EntityIntersect(drone.center(), drone.CAI.lookingAt, blockers[j]);
                    if (intersect) {
                        if (blockers[j].tag === "Player") {

                        }
                        blocked = true;
                        // lineOfSight = intersect;
                        if (vectorMagnitude(vectorSubtract(drone.center(), intersect)) < vectorMagnitude(vectorSubtract(drone.center(), closestIntersect))) {
                            closestIntersect = intersect;
                        }
                    }
                }
                drone.CAI.lookAt(closestIntersect.x, closestIntersect.y);
                if (drone.CAI.lookingAtEntity(drone, player)) {
                    drone.CAI.lookAt(player.center().x, player.center().y);
                    if (drone.CAI.canDrop()) drone.CAI.drop(drone);
                } else if (!blocked) {
                    drone.CAI.lookAt(drone.facing * (drone.position.x + 400), drone.position.y + 400);
                } else {
                    drone.CAI.lookAt(closestIntersect.x, closestIntersect.y);
                }
                guard = drone;
                // if (!blocked && AIs[i].CAI.canDrop()) {
                //     AIs[i].CAI.drop(AIs[i]);
                // }
            }
            AIs[i].velocity = scalarMultiply(getUnitVector(vectorSubtract(AIs[i].CAI.waypoints[AIs[i].CAI.nextWaypoint], AIs[i].position)), 2);
        }
        else if (AIs[i].CAI.aiType === "follow") {
            // Does this NPC have line of sight on the player?
            let blockers = ENTITY_MANAGER.TileEntities.filter(e => e.CBoundingBox.blocksVision === true);
            let blocked = false;
            for (var j = 0; j < blockers.length; j++) {
                let intersect = EntityIntersect(AIs[i].center(), player.center(), blockers[j]);
                if (intersect) {
                    blocked = true;
                    // lineOfSight = intersect;
                    // guard = AIs[i];
                }
            }
            if (!blocked) {
                AIs[i].CAI.hunt(AIs[i], player);
                if (AIs[i].CWeapon) AIs[i].CAI.shootAt(AIs[i], player);
            }
            if (AIs[i].CAI.isHunting()) {
                if (AIs[i].CAI.isAtNextWaypoint(AIs[i].position)) {
                    AIs[i].CAI.cycleWaypoint();
                }
                if (AIs[i].CAI.path && AIs[i].CAI.path.length < 1) continue;
                AIs[i].velocity = scalarMultiply(getUnitVector(vectorSubtract(scalarMultiply(AIs[i].CAI.next(), 64), AIs[i].position)), 2);
            } else {
                if (AIs[i].CAI.isHome(AIs[i].position)) {
                    AIs[i].velocity = { x: 0, y: 0 };
                } else {
                    AIs[i].CAI.goHome(AIs[i]);
                    if (AIs[i].CAI.path && AIs[i].CAI.path.length < 1) continue;
                    AIs[i].velocity = scalarMultiply(getUnitVector(vectorSubtract(scalarMultiply(AIs[i].CAI.next(), 64), AIs[i].position)), 2);
                }
            }
        }
        else if (AIs[i].CAI.aiType === "sentry") {
            if (AIs[i].CAI.canShoot()) {
                AIs[i].CWeapon.use();
                AIs[i].CAI.lastFired = new Date();
            }
        }
    }
}

// Handles the movement of all entities as well as the player speed
function sMovement() {
    player = ENTITY_MANAGER.player;
    //applies movement to NPCs
    for (var i = 0; i < ENTITY_MANAGER.NPCEntities.length; i++) {
        npc = ENTITY_MANAGER.NPCEntities[i];
        if (npc.CWeight) {
            if (npc.CWeight.weight > 0) {
                npc.velocity.y += gravity;
            }
        }
        npc.position.x += npc.velocity.x;
        npc.position.y += npc.velocity.y;
        if (npc.velocity.x !== 0) npc.facing = Math.sign(npc.velocity.x);
    }
    for (var i = 0; i < ENTITY_MANAGER.TileEntities.length; i++) {
        tile = ENTITY_MANAGER.TileEntities[i];
        if (tile.CWeight) {
            if (tile.CWeight.weight > 0) {
                tile.velocity.y += gravity;
            }
        }
        tile.position.x += tile.velocity.x;
        tile.position.y += tile.velocity.y;
        // if (tile.CAI)
        //     console.log(tile.velocity.y);
    }
    //apply gravity to player
    if (player.CState.state == "wall") {
        player.velocity.y = 0;
        if (!overworldActive && canPressSpace && pressingspace && player.CControllable.canJump && player.CControllable.jumpLeft > 0) {
            canPressSpace = false;
            player.CControllable.canJump = false;
            jumpVelocity = Math.sqrt(Math.pow(jumpPower, 2) / 2);

            player.velocity.y = -jumpVelocity;
            player.velocity.x = -(jumpVelocity * player.CControllable.climbDir);
            player.CControllable.jumpLeft -= 1;
            player.position.x += player.velocity.x;
            player.position.y += player.velocity.y;
            player.setState("air");
            return;

        }
        if (pressingup && !pressingdown) {
            player.position.y -= climbSpeed;
            player.velocity.y = -climbSpeed;
        }
        if (!pressingup && pressingdown) {
            player.position.y += climbSpeed;
            player.velocity.y = climbSpeed;
        }
        player.velocity.x = horzSpeed * player.CControllable.climbDir;
        player.position.x += player.velocity.x;

    }
    else {
        if ((player.velocity.y + gravity) >= maxGravity) {
            player.velocity.y = maxGravity;
        }
        else { player.velocity.y += gravity };

        if (Math.abs(player.velocity.x) * friction < 0.05) {
            player.velocity.x = 0;
        }
        else player.velocity.x = player.velocity.x * friction;

        if (player.velocity.y == 0 && player.velocity.x != 0) {
            player.setState("walk");
        }
        //applies movement to player
        player.position.x += player.velocity.x;
        player.position.y += player.velocity.y;
        if (player.velocity.x !== 0) player.facing = Math.sign(player.velocity.x);
    }
    let bullets = ENTITY_MANAGER.BulletEntities;
    for (var i = 0; i < bullets.length; i++) {
        bullets[i].position.x += bullets[i].velocity.x;
        bullets[i].position.y += bullets[i].velocity.y;
    }
}

// Handles collisions between all entities and each other
function sCollision() {
    //checks if player is spawned.
    player = ENTITY_MANAGER.player;
    if (!player) return;
    if (player.CState.state != "wall" || !pressingshift && player.CState.state != "air") player.setState("air");
    //sets all activation id's to 0. id can range from 0-15.
    for (var i = 0; i < ENTITY_MANAGER.activationID.length; i++) {
        ENTITY_MANAGER.activationID[i] = 0;
    }
    //check all switchs to see if player or NPC is overlaping then, if true then set that switch's activation id to 1.
    for (var i = 0; i < ENTITY_MANAGER.SwitchEntities.length; i++) {
        switchE = ENTITY_MANAGER.SwitchEntities[i];
        overlap = GetOverlap(player, switchE);
        if (overlap[0] < 0 || overlap[1] < 0) {
            for (var j = 0; j < ENTITY_MANAGER.NPCEntities.length; j++) {
                overlap = GetOverlap(ENTITY_MANAGER.NPCEntities[j], switchE);
                if (overlap[0] > 0 && overlap[1] > 0) { ; break; }
            }
        }
        if (overlap[0] > 0 && overlap[1] > 0) {
            //console.log(switchE.CActivate.type);
            if (switchE.CActivate.type == 0) {
                ENTITY_MANAGER.activationID[switchE.CActivate.id] = 1;
            }
        }
        if (switchE.CActivate.type == 1) {
            if (pressinge && player.CControllable.canPressE) {
                if (!(switchE.CState.state === "active" || switchE.CState.state === "open")) switchE.openDoor();
                switchE.CActivate.toggle = 1;
            }
            //console.log("ping")
            if (switchE.CActivate.toggle) {
                ENTITY_MANAGER.activationID[switchE.CActivate.id] = 1;
            }
            else { ENTITY_MANAGER.activationID[switchE.CActivate.id] = 0; }
            //console.log(ENTITY_MANAGER.activationID[2]);
        }

    }
    //check all doors if their activation number is not 0, then do something.
    for (var i = 0; i < ENTITY_MANAGER.DoorEntities.length; i++) {
        door = ENTITY_MANAGER.DoorEntities[i];
        actID = ENTITY_MANAGER.activationID[door.CActivate.id];

        if (actID == 1) {
            if (!(door.CState.state === "active" || door.CState.state === "open")) door.openDoor();
        }
        else {
            door.CBoundingBox.collide = true;
            overlap = GetOverlap(player, door);
            if (overlap[0] >= 0 && overlap[1] >= 0 && door.CBoundingBox.collide) {
                prevOverlap = GetPreviousOverlap(player, door);
                if (prevOverlap[0] > 0) {
                    player.position.y -= overlap[1] * Math.sign(player.velocity.y);
                }
                else { player.position.x -= overlap[0] * Math.sign(player.velocity.x); }
            }
        }
    }
    startClimb = false;
    stillStuck = false;

    // Tile collisions
    let bullets = ENTITY_MANAGER.BulletEntities;
    for (var i = 0; i < ENTITY_MANAGER.TileEntities.length; i++) {
        if (ENTITY_MANAGER.TileEntities[i].CBoundingBox) {
            tile = ENTITY_MANAGER.TileEntities[i];
            // Check Tile/NPC collisions
            for (var j = 0; j < ENTITY_MANAGER.NPCEntities.length; j++) {
                let npc = ENTITY_MANAGER.NPCEntities[j];
                if (npc.tag === "Turret") {//} && tile.position.x > 0 && tile.position.y > 256) {
                    //console.log(npc.position.x);
                }
                let overlap = GetOverlap(npc, tile);
                //console.log(overlap[0]);
                if (overlap[0] > 0 && overlap[1] > 0) {
                    let prevOverlap = GetPreviousOverlap(npc, tile);
                    if (prevOverlap[0] > 0) {
                        let direction = Math.sign(npc.velocity.y);
                        npc.position.y -= overlap[1] * direction;
                        npc.velocity.y = 0;
                    }
                    else if (prevOverlap[1] > 0) {
                        let direction = Math.sign(npc.velocity.x);
                        npc.position.x -= overlap[0] * direction;
                    }
                }
            }
            // Check Tile/Player collisions
            overlap = GetOverlap(player, tile);
            if (overlap[0] > 0 && overlap[1] > 0 && tile.CBoundingBox.collide) {
                prevOverlap = GetPreviousOverlap(player, tile);
                if (player.CState.state == "wall") {
                    if (prevOverlap[0] > 0) {
                        direction = Math.sign(player.velocity.y);
                        player.position.y -= overlap[1] * direction;
                        player.velocity.y = 0;
                        if (direction == 1) {
                            player.CControllable.jumpLeft = player.CControllable.jumpMax;
                            if (player.velocity.x != 0) {
                                player.setState("walk");
                            }
                            else {
                                player.setState("ground");
                            }
                        }
                    }
                    else if (prevOverlap[1] > 0) {
                        player.position.x -= overlap[0] * (player.CControllable.climbDir);
                        stillStuck = true;
                    }

                }
                else {
                    if (prevOverlap[0] > 0) {
                        direction = Math.sign(player.velocity.y);
                        player.position.y -= overlap[1] * direction;
                        player.velocity.y = 0;
                        if (direction == 1) {
                            player.CControllable.jumpLeft = player.CControllable.jumpMax;
                            if (player.velocity.x != 0) {
                                player.setState("walk");
                            }
                            else {
                                player.setState("ground");
                            }
                        }
                    }
                    else if (prevOverlap[1] > 0) {
                        direction = Math.sign(player.velocity.x);
                        player.position.x -= overlap[0] * direction;
                        if (pressingshift) {     //&& player.CControllable.canClimb) {
                            startClimb = true;
                        }
                    }
                }
            }
            // Handle collectables
            if (overlap[0] > 0 && overlap[1] > 0 && tile.CCollectable) {
                if (tile.CCollectable.collectableType === 0) {

                    finishLevel(PLAYER_STATUS.score, PLAYER_STATUS.level_ID);
                }
                if (tile.CCollectable.collectableType === 1) {
                    if (tile.tag === "Star") {
                        tile.destroy();
                        player.CWeapons.push(new CWeapon(tile.CCollectable.tag, tile.CCollectable.ammo, tile.CCollectable.maxAmmo));
                        player.weaponIndex = player.CWeapons.length - 2;
                        player.swapWeapon();
                    }
                }
                if (tile.CCollectable.collectableType === 2) {
                    if (tile.tag === "Heart") {
                        tile.destroy();
                        player.heal(tile.CCollectable.health);
                    }
                }
            }
            // Check Tile/Bullet collisions
            for (var j = 0; j < bullets.length; j++) {
                let bullet = bullets[j];
                overlap = GetOverlap(tile, bullet);
                if (overlap[0] > 0 && overlap[1] > 0) {
                    if (bullet.tag === "Gun" || bullet.tag === "SlashRight") {
                        bullet.destroy();
                    }
                }

            }
        }
    }
    // Check NPC/Bullet collisions
    for (var i = 0; i < bullets.length; i++) {
        let bullet = bullets[i];
        for (var k = 0; k < ENTITY_MANAGER.NPCEntities.length; k++) {
            let npc = ENTITY_MANAGER.NPCEntities[k];
            if ((npc.tag === "Turret" || npc.tag === "Boss") && bullet.tag === "Gun") continue;
            if (npc.CHealth) {
                overlap = GetOverlap(npc, bullet);
                if (overlap[0] > 0 && overlap[1] > 0) {
                    npc.hurt(bullet.CDamage.damage);
                    bullet.destroy();
                }
            }
        }
        if (bullet.tag === "Gun") {
            overlap = GetOverlap(player, bullet);
            if (overlap[0] > 0 && overlap[1] > 0) {
                player.hurt(bullet.CDamage.damage);
                bullet.destroy();
            }
        }
    }
    if (!stillStuck && player.CState.state == "wall") {
        player.setState("air");
    }
    if (startClimb) {
        player.setState("wall");
        //player.CControllable.canClimb = false;
        stillStuck = true;
        player.CControllable.climbDir = direction;
    }
    if (pressinge)
        player.CControllable.canPressE = false;
}
//takes userinput from listeners in script to change players velocity/states.
function sUserInput() {

    player = ENTITY_MANAGER.player;
    if (!player) return;

    else if (pressingleft && !pressingright) {
        if (horzSpeed - player.velocity.x >= horzMax) {
            player.velocity.x = -horzMax / friction;
        }
        else player.velocity.x -= horzSpeed / friction;
    }
    else if (!pressingleft && pressingright) {
        if (player.velocity.x + horzSpeed >= horzMax) {
            player.velocity.x = horzMax / friction;
        }
        else player.velocity.x += horzSpeed / friction;
    }
    else {
        //player.velocity.x = 0;
    }
    if (!overworldActive && canPressSpace && pressingspace && player.CControllable.jumpLeft > 0 && player.CControllable.canJump && player.CState.state != "wall") {
        canPressSpace = false;
        player.CControllable.canJump = false;
        player.velocity.y = -jumpPower;
        player.CControllable.jumpLeft -= 1;
        //player.CState.state = "air";

    }

    if (pressingx) {
        if (canPressX) {
            player.CWeapon.use();
            canPressX = false;
        }
    }
    if (pressingf) {
        if (canPressF) {
            player.swapWeapon();
            canPressF = false;
        }
    }
}


function sLifespan() {
    // As of now bullets are the only entities that die of old age
    let bullets = ENTITY_MANAGER.BulletEntities;
    for (var i = 0; i < bullets.length; i++) {
        if (bullets[i].CLifespan) {
            if (bullets[i].CLifespan.isTooOld()) bullets[i].destroy();
        }
    }
}
// Update the camera position
// TODO: Stop scrolling at the end of levels
function sCamera(player) {
    if (!player) return;
    camera.follow(player);
}
// Handle redrawing the canvas
function sRender(ctx) {
    ctx.clearRect(0, 0, 1024, 576);
    ctx.drawImage(ASSET_MANAGER.cache[SPRITE_MAP.get("Overworld")[0]], 0, 0);
    if (overworldActive) {
    }
    let entities = ENTITY_MANAGER.getEntities();
    for (var i = 0; i < entities.length; i++) {
        for (var j = 0; j < entities[i].length; j++) {


            entities[i][j].draw(ctx)
            //Dummy text what I think drawImage should somehow look like with Animation
            //ctx.drawImage(sprite, currentFrame*frameWidth, 0, frameWidth, frameHeight, entityCameraX, entityCameraY, 64, 64);
        }
    }
}

/**
*	Draw HUD, to show Score, Amunition and Health
*/
function displayHUD(ctx) {
    if (!ENTITY_MANAGER.getPlayer().CHealth) return;
    let player = ENTITY_MANAGER.getPlayer();
    ctx.save();
    ctx.drawImage(ASSET_MANAGER.cache['./client/images/orange.png'], 854, 10, 150, 150);
    ctx.font = "15px Arial";
    ctx.fillStyle = "black";
    ctx.textAlign = "left";
    ctx.fillText(`Health: ${player.CHealth.currentHealth} / ${player.CHealth.maxHealth}`, 864, 30);
    ctx.fillText(`Score: ${PLAYER_STATUS.score}`, 864, 50);
    ctx.fillText(`Ammunition: ${(player.CWeapon.maxAmmo === "0") ? '∞' : (player.CWeapon.ammo + ' / ' + player.CWeapon.maxAmmo)}`, 864, 70);
    ctx.fillText(`Equipped: `, 864, 100);
    ctx.fillText(player.CWeapon.weaponName, 864, 120);
    ctx.strokeStyle = "white"
    ctx.strokeRect(934, 85, 64, 64);
    ctx.fillStyle = "black";
    ctx.fillRect(934, 85, 64, 64);
    ctx.drawImage(player.CWeapon.icon, 934, 85);
    ctx.restore();
}

// Main game loop
function gameLoop() {
    if (document.getElementById("loginDiv").style.display === "block") return;
    ENTITY_MANAGER.updateEntities();
    if (MENU_MANAGER.menuStack[0]) {
        // if a menu is open, pause the game
        // switch to menu rendering
        // menuState is defined in MenuEngine.js
        menuState(ctx);
    } else if (overworldActive) {
        overworldState();
    } else {
        sAI();
        sUserInput();
        sMovement();
        sLifespan();
        sCollision();
        sCamera(ENTITY_MANAGER.getPlayer());
        sRender(ctx);
        displayHUD(ctx, ENTITY_MANAGER.getPlayer());
    }
    requestAnimationFrame(gameLoop);
}
let pressingright = false;
let pressingleft = false;
let pressingup = false;
let pressingdown = false;
let pressingspace = false;
let pressingshift = false;
let pressingx = false;
let pressingf = false;
let canPressF = true;
let canPressX = true;
let canPressSpace = true;
let pressinge = false;

let gravity = 0.5;  //downward force
let maxGravity = 5; //highest it can get
let jumpPower = 9;
let horzSpeed = 2.5;
let friction = 0.6;
let horzMax = 4.5;
let climbSpeed = 3;
let frameCount = 0;
let frameWidth = 64;
let frameHeight = 0;
let currentFrame = 0;
const totalFramesStanding = 4;
const totalFramesWalking = 4;
const totalFramesJumping = 6;

let camera = new Camera(1024, 576, 0, 0, 200, 200);
