// CLASS DECLARATIONS
// MenuManager maintains the stack of all currently open menus
// It aggregates Menus on the stack and tracks which is the active one
class MenuManager {
    constructor() {
        this.menuStack = [];
    }
    peekTop() {
        // Check the menu on top of all the others, don't pop it
        return this.menuStack[this.menuStack.length - 1];
    }
    openMenu(menu) {
        this.menuStack.push(menu);
    }
    closeMenu() {
        this.menuStack.pop();
    }
    drawMenus(ctx) {
        let top = MENU_MANAGER.peekTop();
        ctx.clearRect(top.x, top.y, top.width, top.height);
        top.drawMenu(ctx);
    }
}

// A Menu aggregates Buttons and allows us to switch menu states
// by popping/pushing menus onto the MenuManager's menuStack array.
// It also has a background image that is drawn to canvas.
// Params: {
//  x, y, width, height: Number (The coordinates and dimensions of the menu on canvas)
//  backgroundImage: String (The path to the menu's background image)
//  buttons: List (List of the buttons associated with this particular menu)
// }
class Menu {
    constructor(x, y, width, height, backgroundImage, buttons) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.buttons = buttons;
        this.backgroundImage = ASSET_MANAGER.cache[backgroundImage];
        this.active = false;
    }
    drawMenu(ctx) {
        ctx.drawImage(this.backgroundImage, this.x, this.y, this.width, this.height);
        // ctx.fillText("Main Menu", this.x + this.width / 2, this.y + this.height / 2);
        for (let i = 0; i < this.buttons.length; i++) {
            this.buttons[i].drawButton(ctx);
        }
    }

    // Probably won't need the add/remove functions tbh
    addButton(button) {
        this.buttons.push(button);
    }
    removeButton(label) {
        this.buttons = this.buttons.filter(button => button.text !== label);
    }
    // open() {
    //     this.active = true;
    // }
    // close() {
    //     this.active = false;
    // }
}

// A Button is just an image with text that is drawn onto Menus
// and has a pointWithin function that checks whether the mouse is on the button.
// There is also a state property that monitors "normal", "pressed", and "hovered" states
// so that each state corresponds with a different appearance.
// When clicked, the Button's this.callback function should be called with this.args as arguments.

// Params: {
//  x, y, width, height: Number (coordinates and dimensions of the Button on canvas)
//  state: String ("normal", "pressed", "hovered" to refer to each state)
//  imagepath: String (path to the button's sprite file)
//  text: String (button's label)
//  callback: Function (Callback function for this button, e.g. the quit button should close the level)
// }
class Button {
    constructor(x, y, width, height, state, imagepath, text, callback, args) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.state = state;
        this.image = ASSET_MANAGER.cache[imagepath];

        this.imageShift = 1;
        this.text = text;
        this.callback = callback;

        // We need to store arguments for the callback like this because otherwise it'll fire as
        // soon as we create the button. Instead we store it and use the 
        // press() function to put them both together and do the callback.
        // We only use this for the levelSelectMenu since we have to tell it what level to load.
        this.args = args;
    }
    pointWithin(mouseX, mouseY) {
        return (mouseX > this.x && mouseX < this.x + this.width && mouseY > this.y && mouseY < this.y + this.height);
    }
    press() {
        if (this.callback) this.callback(this.args);
    }
    drawButton(ctx) {
        if (this.state === "normal") ctx.drawImage(this.image, this.imageShift * 0, 0, 1, 1, this.x, this.y, this.width, this.height);
        if (this.state === "hovered") ctx.drawImage(this.image, this.imageShift * 1, 0, 1, 1, this.x, this.y, this.width, this.height);
        if (this.state === "pressed") ctx.drawImage(this.image, this.imageShift * 2, 0, 1, 1, this.x, this.y, this.width, this.height);
        // ctx.fillRect(this.x, this.y, this.width, this.height);
        ctx.fillStyle = 'white';
        ctx.textAlign = "center";
        ctx.fillText(this.text, this.x + this.width / 2, 5 + this.y + this.height / 2);
    }
}

// A Slider extends the Button class so that it can be aggregated in Menus and 
// we can point our InputListeners to them very easily.
// We override the necessary methods so it will work with mouse dragging.

// Params: {
//  x, y, width, height: Number (coordinates and dimensions of the Slider rectangle on canvas)
//  state: String (same values as Button, plus "dragged")
//  imagepath: String (path to the button's sprite file - not needed for Sliders)
//  text: String (Slider's label)
//  callback, args: Function (Same as button, but callback is whenever knob is clicked OR dragged)
//  current: Number (Starting value - must be between 0.0 and 1.0. Defaults to 0.5, meaning 50%.)
// }
class Slider extends Button {
    constructor(x, y, width, height, state, imagepath, text, callback, args, current) {
        super(x, y, width, height, state, imagepath, text, callback, args);
        this.current = current || 0.5;
    }
    // Override "press" so it can take the xcoord of the mouse 
    // from the Mouse Event, which is needed for the slider knob
    press(xcoord) {
        this.callback(xcoord);
    }
    // Convert the pixel X coordinate to a decimal percentage
    // and store it in the slider's this.current value
    setCurrent(mouseX) {
        if (mouseX > this.x + this.width - 10) {
            this.current = 1.0;
        } else if (mouseX < this.x + 10) {
            this.current = 0.0;
        } else {
            this.current = (mouseX - this.x + 1) / (this.width);
        }
    }

    // Convert this.current into a pixel value to render the slider knob
    getCurrentPosition() {
        return this.x + (this.current * this.width);
    }
    // Override drawButton because we need to dynamically render the knob
    drawButton(ctx) {
        ctx.fillStyle = "white";
        // Draw background
        // ctx.drawImage(this.image, 0, 0, 1, 1, this.x, this.y, this.width, this.height);
        ctx.fillRect(this.x - 5, this.y, this.width + 10, this.height + 10);
        // Draw slider line
        ctx.fillStyle = "#FF0000";
        ctx.fillRect(this.x + 5, this.y + 10 + (this.height / 2), this.width - 10, 5);
        // Draw slider label
        ctx.save();
        ctx.font = "10px Verdana";
        ctx.textAlign = "center";
        ctx.fillStyle = "black";
        ctx.fillText(this.text, this.x + (this.width / 2), this.y + 10);
        ctx.restore();
        // Draw slider knob
        ctx.fillStyle = "#000";
        ctx.fillRect(this.getCurrentPosition() - 5, this.y + 18, 10, this.height - 10);
        ctx.restore();
    }
}

function sMenuInput() {

}

// Load test level from /client
function loadTestLevel() {
    $.ajax({
        url: `/client/campaign/testLevel.txt`,
        method: "GET",
        success: function (result) {
            loadLevelFromText(result);
            PLAYER_STATUS.campaign_pickups = ACCOUNT.campaign_pickups;
        }
    });
}
// Load entity data from a string
function loadLevelFromText(text) {
    console.log("Proceeding with level text: " + text);
    PLAYER_STATUS.score = 0;
    ENTITY_MANAGER.resetEntities();
    let entityList = text.split(/,\s*/); //make sure entities are separated by a comma (and trailing whitespace)
    for (var i = 0; i < entityList.length; i++) {
        ENTITY_MANAGER.initializeEntity(entityList[i]);
    }
    camera = new Camera(1024, 576, 0, 0, 200, 200);

    MENU_MANAGER.lastMenuStack = MENU_MANAGER.menuStack; // remember what menu we started the level from
    MENU_MANAGER.menuStack = []; // close all menus
    overworldActive = false;
}

// Clear all entities and reset the menuStack to what it was when the level started
// so we can track if we should return to overworld/level select, etc.
function quitLevel() {
    ENTITY_MANAGER.resetEntities();
    if (startedFromOverworld) {
        // If you're quitting from the overworld screen, return to main menu
        if (overworldActive) {
            overworldActive = false;
            startedFromOverworld = false;
            MENU_MANAGER.menuStack = [mainMenu];
        } else {
            // If you're quitting a level launched from the overworld screen,
            // just return to the overworld screen
            overworldStart();
        }
    } else {
        // In all other cases just go back to whatever menu you were on
        MENU_MANAGER.menuStack = MENU_MANAGER.lastMenuStack;
    }
}

function optionsMenu() {
    MENU_MANAGER.openMenu(new Menu(
        380, 180, 240, 240, "./client/images/orange.png", [
        SFXVolumeSlider,
        MusicVolumeSlider,
        CancelButton
    ]
    ));
}
const SFXVolumeSlider = new Slider(430, 210, 150, 50, null, "./client/images/green.png", "SFX Volume", function (mouseX) {
    this.setCurrent(mouseX);
});
const MusicVolumeSlider = new Slider(430, 290, 150, 50, null, "./client/images/green.png", "Music Volume", function (mouseX) {
    this.setCurrent(mouseX);
});
const CancelButton = new Button(450, 360, 110, 30, "normal", "./client/images/green.png", "OK", function () { MENU_MANAGER.closeMenu(); });
function loadLevel(levelID) {
    $.ajax({
        url: "/db/levels/" + levelID,
        method: "GET",
        success: function (result) {
            startedFromOverworld = false;
            PLAYER_STATUS.level_ID = levelID;
            loadLevelFromText(result.data);
        }
    });
}
function loadCampaignLevel(levelID) {
    $.ajax({
        url: `/client/campaign/level${levelID}.txt`,
        method: "GET",
        success: function (result) {
            loadLevelFromText(result);
            PLAYER_STATUS.level_ID = levelID;
            PLAYER_STATUS.campaign_pickups = ACCOUNT.campaign_pickups;
        }
    });
}
function levelSelectMenu() {
    $.ajax({
        url: '/db/levels',
        method: "GET",
        success: function (result) {
            let levelButtons = [];
            for (let i = 0; i < result.levels.length; i++) {
                levelButtons.push(new Button(
                    30 + (i % 9) * 110,
                    30 + Math.floor(i / 9) * 110,
                    100,
                    100,
                    "normal",
                    "./client/images/orange.png",
                    result.levels[i].level_ID + " by author " + result.levels[0].author,
                    loadLevel,
                    result.levels[i].level_ID
                )
                );
            }
            let levelSelectMenu = new Menu(0, 0, 1024, 576, "./client/images/blue.png", levelButtons);
            MENU_MANAGER.openMenu(levelSelectMenu);
        }
    });
}

function logout() {
    if (loggingout) return; // Verify we are not already waiting for a response from the server
    loggingout = true;
    $.ajax({
        url: '/logout',
        method: "POST",
        success: function (result) {
            ENTITY_MANAGER.resetEntities();
            MENU_MANAGER.menuStack = [];
            alert(result.message);
            loggingout = false;
            openLogin();
        }
    });
}

function deleteAccount() {
    // Show Deleting Form
    openDeleteForm();
}

function createLevel() {
    // add level
    openAddLevelForm();
}

const MENU_MANAGER = new MenuManager();

// MENU SETUP
// Pause Menu
const pauseMenu = new Menu(350, 150, 300, 300, "./client/images/blue.png", [
    new Button(400, 200, 200, 50, "normal", "./client/images/green.png", "Resume Game", function () { MENU_MANAGER.closeMenu(); }),
    new Button(400, 275, 200, 50, "normal", "./client/images/green.png", "Options", function () { optionsMenu(); }),
    new Button(400, 350, 200, 50, "normal", "./client/images/green.png", "Quit Level", function () { quitLevel(); })
]);

// Main Menu
const mainMenu = new Menu(0, 0, 1024, 576, './client/images/blue.png', [
    new Button(400, 80, 200, 50, "normal", "./client/images/green.png", "Load Test Level", loadTestLevel),
    new Button(400, 150, 200, 50, "normal", "./client/images/green.png", "Level Select", levelSelectMenu),
    new Button(400, 220, 200, 50, "normal", "./client/images/green.png", "Overworld Screen", overworldStart),
    new Button(400, 290, 200, 50, "normal", "./client/images/green.png", "View Leaderboards", openScoresMenu),
    new Button(400, 360, 200, 50, "normal", "./client/images/green.png", "Add Level", createLevel),
    new Button(400, 430, 200, 50, "normal", "./client/images/green.png", "Delete Account", deleteAccount),
    new Button(400, 500, 200, 50, "normal", "./client/images/green.png", "Log Out", logout),
]);
function openScoresMenu() {
    $.ajax({
        url: '/db/levels',
        method: "GET",
        success: function (result) {
            let scoreMenuButtons = [];
            for (let i = 0; i < 5; i++) {
                scoreMenuButtons.push(new Button(
                    40 + (i % 5) * 192,
                    40 + Math.floor(i / 5) * 192,
                    160,
                    160,
                    "normal",
                    "./client/images/orange.png",
                    "Campaign Level " + (i + 1),
                    viewScores,
                    i
                )
                );
            }
            for (let i = 0; i < result.levels.length; i++) {
                scoreMenuButtons.push(new Button(
                    40 + (i % 5) * 192,
                    40 + 192 + Math.floor(i / 5) * 192,
                    160,
                    160,
                    "normal",
                    "./client/images/orange.png",
                    "Custom Level " + result.levels[i].level_ID + " by author " + result.levels[i].author,
                    viewScores,
                    result.levels[i].level_ID
                )
                );
            }
            scoreMenuButtons.push(new Button(864, 300, 100, 50, "normal", "./client/images/green.png", "Go Back", function () { MENU_MANAGER.closeMenu() }))
            let scoreMenu = new Menu(0, 0, 1024, 576, "./client/images/blue.png", scoreMenuButtons);
            MENU_MANAGER.openMenu(scoreMenu);
        }
    });
}
function viewScores(level_ID) {
    $.ajax({
        url: '/db/scores/level/' + level_ID,
        method: "GET",
        success: function (result) {
            let scoreButtons = [];
            if (result.scores.length === 0) {
                displayModal = true;
                modalMade = new Date();
                modalMessage = "No scores submitted yet for that level!";
            } else {
                for (let i = 0; i < result.scores.length; i++) {
                    scoreButtons.push(new Button(
                        200,
                        100 + 35 * i,
                        624,
                        30,
                        "normal",
                        "./client/images/green.png",
                        `Score ${result.scores[i].score} by user ${result.scores[i].username} on ${new Date(result.scores[i].date)}`,
                        viewUserScores,
                        result.scores[i].username
                    ));
                }
                scoreButtons.push(new Button(864, 300, 100, 50, "normal", "./client/images/green.png", "Go Back", function () { MENU_MANAGER.closeMenu() }));
                let leaderBoardMenu = new Menu(190, 90, 644, 396, "./client/images/blue.png", scoreButtons);
                MENU_MANAGER.openMenu(leaderBoardMenu);
                console.log(result);

            }
        }
    });
}
function viewUserScores(username) {
    $.ajax({
        url: '/db/scores/user/' + username,
        method: "GET",
        success: function (result) {
            let scoreButtons = [];
            if (result.scores.length === 0) {
                displayModal = true;
                modalMade = new Date();
                modalMessage = "No scores submitted yet by that user!"; // No idea why this would ever come up but hey
            } else {

                for (let i = 0; i < result.scores.length; i++) {
                    scoreButtons.push(new Button(
                        200,
                        100 + 35 * i,
                        624,
                        30,
                        "normal",
                        "./client/images/green.png",
                        `${result.scores[i].username} scored ${result.scores[i].score} on level ${result.scores[i].level_ID}`
                    ));
                }
                scoreButtons.push(new Button(864, 300, 100, 50, "normal", "./client/images/green.png", "Go Back", function () { MENU_MANAGER.closeMenu() }));
                let userScoresMenu = new Menu(190, 90, 644, 396, "./client/images/orange.png", scoreButtons);
                MENU_MANAGER.openMenu(userScoresMenu);
                console.log(result);
            }
        }
    });
}

function sUserInfo() {
    if ($.isEmptyObject(ACCOUNT)) return; // must be logged in
    if (MENU_MANAGER.peekTop() != mainMenu) return;
    ctx.save();
    ctx.drawImage(ASSET_MANAGER.cache['./client/images/orange.png'], 10, 10, 1004, 30);
    ctx.font = "15px Arial";
    ctx.fillStyle = "black";
    ctx.textAlign = "center";
    ctx.fillText(`Welcome back to Ninja Celeste, ${ACCOUNT.username} !`, 512, 30);
    ctx.restore();
}

// Only runs on frames when a menu is open
function menuState() {
    MENU_MANAGER.drawMenus(ctx);
    sUserInfo();
    sMenuInput();
    if (displayModal) drawModal(ctx);
}
let loggingout = false;

// Post game score to Database
function finishLevel(score, levelid) {
    quitLevel();
    $.post({
        traditional: true,
        url: '/db/addScore',
        contentType: 'application/json',
        data: JSON.stringify({
            'levelid': levelid,
            'score': score
        }),
        dataType: 'json',
    })
        .done(function (res) {
            displayModal = true;
            modalMade = new Date();
            modalMessage = res.message;
        })
        .fail(function (res) {
            console.log(res);
        });
}
let displayModal = false;
let modalMade = false;
let modalMessage = "";
function drawModal(ctx) {
    ctx.save();
    let age = new Date() - modalMade;
    ctx.fillStyle = "rgba(255,255,255, " + (1 - (age / 5000)) + ")";
    ctx.fillRect(200, 75, 624, 100);
    ctx.fillStyle = "rgba(0,0,0, " + (1 - (age / 5000)) + ")";
    ctx.textAlign = "center";
    ctx.font = "24px Arial";
    ctx.fillText(modalMessage, 512, 125, 624);
    ctx.restore();
    if (age > 5000) {
        displayModal = false;
    }
}