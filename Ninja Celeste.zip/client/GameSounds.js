/**
*
* Game Sounds
*
*
* HOW TO USE
*
* If you want to play a sound, just call any of the following function from the code.
* You can add more Sound Effects if needed by adding more functions
* Sound Effects are from Adobe free library
*
*/

/**
* Play a sound when a component moves
* Sound FX is to simulate movement
*/
function playMoveSounds() {
	gameSound = new sound("./Client/Sounds/move.wav");
	gameSound.play();
}

/**
* Play a sound when a component jumps
* Sound FX
*/
function playJumpSounds() {
	gameSound = new sound("./Client/Sounds/jump.wav");
	gameSound.play();
}

/**
* Play a sound when components collide. 
* The sound FX for collision
*/
function playCollisionSound() {
	gameSound = new sound("./Client/Sounds/collision.wav");
	gameSound.play();
}

/**
* Play a sound when firing a bullet
* Sound FX simulates a bullet
*/
function playBulletSound() {
	gameSound = new sound("./Client/Sounds/bullet.wav");
	gameSound.play();
}

/**
* Play a sound when swinging Sword
* Sound FX simulates a sword
*/
function playSwordSound() {
	gameSound = new sound("./Client/Sounds/sword.wav");
	gameSound.play();
}

/**
* Play a sound when a door opens
* Sound FX 
*/
function playDoorSounds() {
	gameSound = new sound("./Client/Sounds/door.wav");
	gameSound.play();
}

/**
* Play a sound when unlocking a new level
* Sound FX simulates victory
*/
function playNewLevelSound() {
	gameSound = new sound("./Client/Sounds/newlevel.wav");
	gameSound.play();
}

/**
* Play game music
* TODO: to add music track
*/
function playGameMusic() {
	musicSound = new sound("");
	musicSound.play();
}

function updateVolume() {
  SFXvolume = SFXVolumeSlider.current;
  MUSICvolume = MusicVolumeSlider.current;
}

/**
* Load Sound FX
*/
function sound(soundurl) {
  this.sound = document.createElement("audio");
  this.sound.src = soundurl;
  this.sound.setAttribute("preload", "auto");
  this.sound.setAttribute("controls", "none");
  this.sound.style.display = "none";
  updateVolume();
  this.sound.volume = SFXvolume;
  document.body.appendChild(this.sound);
  this.play = function(){
    this.sound.play();
  }
  this.stop = function(){
    this.sound.pause();
  }
}


let gameSound;
let musicSound;
let SFXvolume;
let MUSICvolume;