// This is a Node class which is used for pathfinding, and the A-Star
// implementation for this game. All other AI-specific code will be in
// ./Components.js under the CAI class.

// Params are both Objects of form {x: Number, y: Number}
// corresponding to the origin position and destination position
// NOTE: These positions are relative to the grid, NOT to the canvas.
// Remember to divide entity's position by 64 before you pass it as an argument.
// Returns list of Objects {x: Number, y: Number} showing the shortest path.
function astar(origin, destination) {

    // Stop pathfinding beyond a certain range from the NPC
    function isInRange(origin, x, y, rng) {

        let range = rng || 30;  // Search up to this number of 64x64 tiles away from the NPC
        // A higher range means the NPC will look farther to search for a path, but
        // it might slow down the game if it's too high. Default is 15 tiles.

        return Math.abs(origin.x - x) < range && Math.abs(origin.y - y) < range;
    }

    // Initialize
    let openList = [];
    let closedList = [];
    let start = new Node(null, origin);
    let end = new Node(null, destination);
    if (!isInRange(origin, destination.x, destination.y)) return undefined;
    // Add start to the open list
    openList.push(start);

    // Loop until we find the end node
    while (openList.length > 0) {
        let currentNode = openList[0];
        let currentIndex = 0;
        for (var i = 0; i < openList.length; i++) {
            if (openList[i].f < currentNode.f) {
                currentNode = openList[i];
                currentIndex = i;
            }
        }

        // Pop current node off the open list and onto the closed list
        openList.splice(currentIndex, 1);
        closedList.push(currentNode);

        // If destination found
        if (currentNode.same(end)) {
            let path = [];
            let current = currentNode;
            while (current) {
                path.push(current.position);
                current = current.parent;
            }
            path.pop();
            return path;
        }

        // Get valid children
        let valids = [];
        let x = currentNode.position.x;
        let y = currentNode.position.y;

        function isGoal(x1, y1) {
            return (end.position.x === x1 && end.position.y === y1);
        }
        // Add all valid child nodes
        if (isGoal(x + 1, y) || (isInRange(origin, x + 1, y) && !tileIsBlocked(x + 1, y))) valids.push(new Node(currentNode, { x: x + 1, y: y }));
        if (isGoal(x - 1, y) || (isInRange(origin, x - 1, y) && !tileIsBlocked(x - 1, y))) valids.push(new Node(currentNode, { x: x - 1, y: y }));
        if (isGoal(x, y + 1) || (isInRange(origin, x, y + 1) && !tileIsBlocked(x, y + 1))) valids.push(new Node(currentNode, { x: x, y: y + 1 }));
        if (isGoal(x, y - 1) || (isInRange(origin, x, y - 1) && !tileIsBlocked(x, y - 1))) valids.push(new Node(currentNode, { x: x, y: y - 1 }));
        // if (isGoal(x + 1, y + 1) || (isInRange(origin, x + 1, y + 1) && !tileIsBlocked(x + 1, y + 1))) valids.push(new Node(currentNode, { x: x + 1, y: y + 1 }));
        // if (isGoal(x + 1, y - 1) || (isInRange(origin, x + 1, y - 1) && !tileIsBlocked(x + 1, y - 1))) valids.push(new Node(currentNode, { x: x + 1, y: y - 1 }));
        // if (isGoal(x - 1, y + 1) || (isInRange(origin, x - 1, y + 1) && !tileIsBlocked(x - 1, y + 1))) valids.push(new Node(currentNode, { x: x - 1, y: y + 1 }));
        // if (isGoal(x - 1, y - 1) || (isInRange(origin, x - 1, y - 1) && !tileIsBlocked(x - 1, y - 1))) valids.push(new Node(currentNode, { x: x - 1, y: y - 1 }));

        // Loop through children to get cost
        for (var i = 0; i < valids.length; i++) {
            // If child is already on the closed list, skip
            if (closedList.find(e => e.same(valids[i]))) continue;
            // Generate cost + heuristic values
            valids[i].g = currentNode.g + 1;
            valids[i].h = (Math.pow(valids[i].position.x - end.position.x, 2) + Math.pow(valids[i].position.y - end.position.y, 2));
            valids[i].f = valids[i].g + valids[i].h;

            // If child is already on the open list, AND has a higher cost, skip
            for (var j = 0; j < openList.length; j++) {
                if (valids[i].same(openList[j]) && valids[i].g > openList[j].g) continue;
            }

            // Finally, add child to open list
            openList.push(valids[i]);
        }
    }
}
class Node {
    constructor(parent, position) {
        this.parent = parent;
        this.position = position;
        this.g = 0;
        this.h = 0;
        this.f = 0;
    }
    same(otherNode) {
        return this.position.x === otherNode.position.x && this.position.y === otherNode.position.y;
    }
}