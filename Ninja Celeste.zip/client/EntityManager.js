// Entity class
// For now it just holds some data for location on the canvas
// It also handles its own spawn coordinates. Should it though? idk
class Entity {
    constructor(tag, spritepath, position, velocity, parent) {
        this.tag = tag;
        this.sprite = ASSET_MANAGER.cache[spritepath];
        this.position = { x: position.x * 64, y: position.y * 64 } || { x: 0, y: 0 };
        this.velocity = velocity || { x: 0, y: 0 };
        this.active = true;
        this.parent = parent;
        // 1 is right, -1 is left
        this.facing = 1;
        this.weaponIndex = 0;
    }
    destroy() {
        if (this.CScore) {
            PLAYER_STATUS.score += this.CScore.getScore();
        }
        this.active = false;
    }
    hurt(damage) {
        if (this.CHealth) {
            this.CHealth.hurt(damage);
            if (this.CHealth.currentHealth < 1) this.destroy();
        }
    }
    heal(damage) {
        if (this.CHealth) {
            this.CHealth.heal(damage);
        }
    }
    center() {
        let centerx = null;
        let centery = null;
        if (this.CBoundingBox) {
            centerx = this.position.x + this.CBoundingBox.length / 2;
            centery = this.position.y + this.CBoundingBox.height / 2;
        } else {
            centerx = this.position.x + this.sprite.width / 2;
            centery = this.position.y + this.sprite.height / 2;
        }
        return { x: centerx, y: centery };
    }
    doWhenAnimationIsFinished(state, callback) {
        this.setState(state);
        this.CAnimation.callback = callback;
    }
    openDoor() {
        this.doWhenAnimationIsFinished("active", () => {
            this.setState('open');
            if (this.CBoundingBox) this.CBoundingBox.collide = false;
        });
    }
    setState(state) {
        if (this.CState.state === state) return;
        this.CState.state = state;

    }
    swapWeapon() {
        if (!this.CWeapons) return;
        this.weaponIndex++;
        if (this.weaponIndex > this.CWeapons.length - 1) {
            this.weaponIndex = 0;
        }
        this.equipWeapon(this.CWeapons[this.weaponIndex]);
    }
    equipWeapon(cweapon) {
        this.CWeapon = cweapon;
    }
    draw(ctx) {

        // Use EntityManager to get the entity's sprite and position
        // and use the Camera to get the entity's position on the canvas
        let face = (this.facing === 1) ? 1 : 0;
        if (this.CState) this.CAnimation.setAnimation(this.CAnimation.stateMap.get(this.CState.state)[face]);
        this.CAnimation.update();
        let entityCameraX = this.position.x - camera.left;
        let entityCameraY = this.position.y - camera.top;
        if (this.CAnimation.animation && this.CAnimation.numberOfFrames > 1) {
            ctx.drawImage(this.CAnimation.animation, this.CAnimation.imageShift * this.CAnimation.currentFrame, 0, this.CAnimation.imageShift, this.CAnimation.animation.height, entityCameraX, entityCameraY, this.CAnimation.imageShift, this.CAnimation.animation.height);
        } else if (this.CAnimation.animation) {
            ctx.drawImage(this.CAnimation.animation, entityCameraX, entityCameraY);
        } else {
            ctx.drawImage(this.sprite, entityCameraX, entityCameraY);
        }
        if (this.CAI && this.tag === "Drone") {
            ctx.save();
            ctx.lineWidth = 4;
            ctx.strokeStyle = "rgba(255,0,0,0.5)";
            ctx.beginPath();
            ctx.moveTo(this.center().x - camera.left, this.center().y - camera.top);
            ctx.lineTo(this.CAI.lookingAt.x - camera.left, this.CAI.lookingAt.y - camera.top);
            ctx.stroke();
            ctx.lineWidth = 2;
            ctx.strokeStyle = "rgba(255,0,0,1)";
            ctx.beginPath();
            ctx.moveTo(this.center().x - camera.left, this.center().y - camera.top);
            ctx.lineTo(this.CAI.lookingAt.x - camera.left, this.CAI.lookingAt.y - camera.top);
            ctx.stroke();
            ctx.restore();
        }
        if (this.CHealth) {
            let width = 0;
            (this.CBoundingBox) ? width = this.CBoundingBox.length : this.sprite.width;
            ctx.save();
            ctx.fillStyle = "red";
            ctx.fillRect(entityCameraX, entityCameraY - 10, width, 10);
            ctx.fillStyle = "#50C878";
            ctx.fillRect(entityCameraX, entityCameraY - 10, width * (this.CHealth.currentHealth / this.CHealth.maxHealth), 10);
            ctx.restore();
        }
    }
}

// EntityManager class
// Creates/destroys entities and manages adding them to the game between frames
// Also holds the sprite map (so we can attach images to newly-created entities)

class EntityManager {
    constructor() {
        this.entitiesToAdd = [];
        this.entitiesToRemove = [];
        this.entities = [];
        this.BGEntities = []; //array of background tiles that have no effect
        this.TileEntities = []; //array of all solid stationary tile blocks
        this.NPCEntities = []; //array of all enemy entities.
        this.SwitchEntities = []; //array of all buttons/switches
        this.DoorEntities = []; //array of activatable tiles.
        this.BulletEntities = [];
        this.lastPaused = Date.now(); // will be used to refresh entity lifespans when unpausing the game
        this.activationID = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    }
    createEntity(name, position, velocity, components) {
        let p;
        let v;
        let tag;
        !position ? (p = { x: 0, y: 0 }) : (p = position);
        !velocity ? (v = { x: 0, y: 0 }) : (v = velocity);
        tag = SPRITE_MAP.get(name)
        if (!tag) {
            console.log("Help");
        }
        let newE = new Entity(name, tag[0], p, v);
        let comp = components.split(" ");
        newE.CAnimation = new CAnimation(name);
        //console.log(comp);
        for (var i = 0; i < comp.length; i++) {
            if (comp[0] === "") break;
            switch (comp[i]) {
                case "CBoundingBox":
                    newE.CBoundingBox = new CBoundingBox(parseInt(comp[i + 1]), parseInt(comp[i + 2]), comp[i + 3], comp[i + 4]);
                    i += 4;
                    break;
                case "CState":
                    newE.CState = new CState(comp[i + 1]);
                    i += 1;
                    break;
                case "CHealth":
                    newE.CHealth = new CHealth(parseInt(comp[i + 1]), parseInt(comp[i + 2]));
                    i += 2;
                    break;
                case "CWeight":
                    newE.CWeight = new CWeight(parseInt(comp[i + 1]));
                    i += 1;
                    break;
                case "CAI":
                    newE.CAI = new CAI(comp[i + 1]);
                    if (comp[i + 1] === "patrol") {
                        let numberOfWaypoints = parseInt(comp[i + 2]);
                        i += 2;
                        while (numberOfWaypoints > 0) {
                            if (isNaN(comp[i + 1])) {
                                console.error(`ERROR ADDING WAYPOINTS: For entity ${newE.tag} with CAI ${newE.CAI.type}: Number of waypoints incorrect.\nPlease ensure the number following "patrol" is equal to the number of "x y" coordinate PAIRS after that token.`);
                                break;
                            }
                            newE.CAI.waypoints.push({ x: parseInt(comp[i + 1]), y: parseInt(comp[i + 2]) });
                            i += 2;
                            numberOfWaypoints--;
                        }
                        newE.CAI.makePatrolPath(position.x, position.y);
                    }
                    if (comp[i + 1] === "follow") {
                        newE.CAI.home = { x: parseInt(comp[i + 2]), y: parseInt(comp[i + 3]) };
                        i += 3;
                    }
                    if (comp[i + 1] === "sentry") {
                        i += 1;
                    }
                    break;
                case "CDropItem":
                    break;
                case "CCollectable":
                    if (comp[i + 1] === "1") {
                        newE.CCollectable = new CCollectable(parseInt(comp[i + 1]), comp[i + 2], parseInt(comp[i + 3]), parseInt(comp[i + 4]));
                        i += 4;
                    } else if (comp[i + 1] === "2") {
                        newE.CCollectable = new CCollectable(parseInt(comp[i + 1]), parseInt(comp[i + 2]));
                        i += 2;
                    } else {
                        newE.CCollectable = new CCollectable(parseInt(comp[i + 1]));
                        i += 1;
                    }
                    break;
                case "CControllable":
                    break;
                case "CActivate":
                    newE.CActivate = new CActivate(comp[i + 1], comp[i + 2]);
                    i += 2;
                    break;
                case "CScore":
                    newE.CScore = new CScore(comp[i + 1]);
                    i += 1;
                    break;
                case "CWeapon":
                    if (!newE.CWeapons) newE.CWeapons = [];
                    newE.CWeapons.push(new CWeapon(comp[i + 1], comp[i + 2], comp[i + 3], newE));
                    i += 3;
                    newE.CWeapon = newE.CWeapons[0];
                    break;
                case "CLifespan":
                    newE.CLifespan = new CLifespan(comp[i + 1]);
                    i += 1;
                    break;
                case "CDamage":
                    newE.CDamage = new CDamage(comp[i + 1]);
                    i += 1;
                    break;
                default:
                    console.error("ERROR PARSING COMPONENT LIST: " + comp + "\nAT TOKEN" + comp[i]);
                    (i < 1) ? console.error("\nAT START OF LIST") : console.error("\nAFTER " + comp[i - 1]);
                    break;
            }
        }
        switch (tag[1]) {
            case "bg":
                this.BGEntities.push(newE);
                break;
            case "tile":
                this.TileEntities.push(newE);
                break;
            case "switch":
                newE.CState = new CState("closed");
                this.SwitchEntities.push(newE);
                break;
            case "door":
                newE.CState = new CState("closed");
                //newE.setState("closed");
                this.DoorEntities.push(newE);
                break;
            case "npc":
                this.NPCEntities.push(newE);
                if (!newE.CScore) newE.CScore = new CScore(100);
                if (!newE.CHealth) newE.CHealth = new CHealth();
                break;
            case "player":
                newE.CState = new CState("air");
                newE.CControllable = new CControllable(2);
                newE.CWeight = new CWeight(2);
                this.player = newE;
                break;
            case "bullet":
                this.BulletEntities.push(newE);
                break;
        }
        // this.entities.push(newE);
        //this.entitiesToAdd.push(newE);
    }
    // TODO: Should this be in the Entity class?
    destroyEntity(entity) {
        entity.destroy();
    }
    // Returns the first entity with the tag "Player"
    // Should be changed if for some reason we ever have > 1 player entity
    getPlayer() {
        // return this.entities.find(entity => entity.tag == "Player");
        return this.player;
    }
    // Wrapper for createEntity: convert string from the level file to entity
    initializeEntity(entity) {
        const ec = entity.split(" ");
        const comp = entity.substring(entity.indexOf("{") + 1, entity.indexOf("}"));
        this.createEntity(
            ec[0],
            { x: Number(ec[1]), y: Number(ec[2]) },
            { x: Number(ec[3]), y: Number(ec[4]) },
            comp
        );
    }
    updateEntities() {
        // Remove non-active entities 
        this.BGEntities = this.BGEntities.filter(e => e.active === true);
        this.TileEntities = this.TileEntities.filter(e => e.active === true);
        this.SwitchEntities = this.SwitchEntities.filter(e => e.active === true);
        this.DoorEntities = this.DoorEntities.filter(e => e.active === true);
        this.NPCEntities = this.NPCEntities.filter(e => e.active === true);
        this.BulletEntities = this.BulletEntities.filter(e => e.active === true);
        if (this.player && this.player.active !== true) {
            quitLevel();
        }

        // Add new entities
        for (var i = 0; i < this.entitiesToAdd.length; i++) {
            initializeEntity(this.entitiesToAdd[i]);
            //this.entities.push(this.entitiesToAdd[i]);
        }

        this.entitiesToAdd = [];
    }
    getEntities() {
        return [this.BGEntities, this.TileEntities, this.SwitchEntities, this.DoorEntities, this.NPCEntities, [this.player], this.BulletEntities];
    }
    resetEntities() {
        this.entitiesToAdd = [];
        this.entitiesToRemove = [];
        this.entities = [];
        this.BGEntities = [];
        this.TileEntities = [];
        this.NPCEntities = [];
        this.SwitchEntities = [];
        this.DoorEntities = [];
        this.BulletEntities = [];
    }
}


