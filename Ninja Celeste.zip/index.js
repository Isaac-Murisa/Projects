// This is the entry point for the project (for now, anyway)
const express = require("express");
const cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
const app = express();
const serv = require("http").Server(app);

// Handle serving static index.html file

app.get("/", function(req, res) {
    res.sendFile(__dirname + "/client/index.html");
});
app.use("/client", express.static(__dirname + "/client"));

// Enable sending JSON as responses
app.use(express.json());

app.use(bodyParser.urlencoded({extended:true}));
app.use(cookieParser());

// Use API endpoints
const routes = require("./game/server/routes");
app.use(routes.router);
app.use((req,res,next)=>{
    const authToken = req.cookies['AuthToken'];
    req.user = routes.authTokens[authToken];

    next();
});

serv.listen(8000);

console.log("Listening on localhost:8000");
